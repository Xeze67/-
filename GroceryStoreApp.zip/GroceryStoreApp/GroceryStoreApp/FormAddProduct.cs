using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace GroceryStoreApp
{
    /// <summary>
    /// Окно удобного добавления нового товара в базу данных Access
    /// </summary>
    public class FormAddProduct : Form
    {
        private TextBox txtBarcode;
        private TextBox txtName;
        private TextBox txtPrice;
        private TextBox txtWeight;
        private Button btnSubmit;
        private Button btnCancel;

        public string Barcode => txtBarcode.Text.Trim();
        public string ItemName => txtName.Text.Trim();
        public decimal Price { get; private set; }
        public double Weight { get; private set; }

        public FormAddProduct()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Добавление нового товара";
            this.Size = new Size(450, 330);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(204)));

            Label lblTitle = new Label
            {
                Text = "Параметры нового товара для базы данных:",
                Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(204))),
                Location = new Point(20, 15),
                AutoSize = true
            };

            // Штрихкод
            Label lblBarcode = new Label { Text = "Штрихкод (EAN-13):", Location = new Point(20, 52), AutoSize = true };
            txtBarcode = new TextBox { Location = new Point(190, 50), Width = 220 };

            // Наименование
            Label lblName = new Label { Text = "Наименование товара:", Location = new Point(20, 92), AutoSize = true };
            txtName = new TextBox { Location = new Point(190, 90), Width = 220 };

            // Цена
            Label lblPrice = new Label { Text = "Цена (руб.):", Location = new Point(20, 132), AutoSize = true };
            txtPrice = new TextBox { Location = new Point(190, 130), Width = 220 };

            // Вес
            Label lblWeight = new Label { Text = "Вес (кг):", Location = new Point(20, 172), AutoSize = true };
            txtWeight = new TextBox { Location = new Point(190, 170), Width = 220 };

            // Кнопка Сохранить в БД
            btnSubmit = new Button
            {
                Text = "Добавить в базу",
                Location = new Point(170, 225),
                Size = new Size(140, 38),
                Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(204))),
                UseVisualStyleBackColor = true
            };
            btnSubmit.Click += BtnSubmit_Click;

            // Кнопка Отмена
            btnCancel = new Button
            {
                Text = "Отмена",
                Location = new Point(320, 225),
                Size = new Size(90, 38),
                UseVisualStyleBackColor = true
            };
            btnCancel.Click += (s, e) => { this.DialogResult = DialogResult.Cancel; this.Close(); };

            this.Controls.Add(lblTitle);
            this.Controls.Add(lblBarcode);
            this.Controls.Add(txtBarcode);
            this.Controls.Add(lblName);
            this.Controls.Add(txtName);
            this.Controls.Add(lblPrice);
            this.Controls.Add(txtPrice);
            this.Controls.Add(lblWeight);
            this.Controls.Add(txtWeight);
            this.Controls.Add(btnSubmit);
            this.Controls.Add(btnCancel);

            this.AcceptButton = btnSubmit;
            this.CancelButton = btnCancel;
        }

        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Barcode))
            {
                MessageBox.Show("Пожалуйста, введите штрихкод товара.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtBarcode.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(ItemName))
            {
                MessageBox.Show("Пожалуйста, введите наименование товара.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtName.Focus();
                return;
            }

            string priceStr = txtPrice.Text.Trim().Replace(',', '.');
            if (!decimal.TryParse(priceStr, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal price) || price <= 0)
            {
                MessageBox.Show("Укажите корректную цену товара (например, 89.90).", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPrice.Focus();
                return;
            }
            Price = price;

            string weightStr = txtWeight.Text.Trim().Replace(',', '.');
            if (!double.TryParse(weightStr, NumberStyles.Any, CultureInfo.InvariantCulture, out double weight) || weight <= 0)
            {
                MessageBox.Show("Укажите корректный вес товара в кг (например, 0.5 или 1.0).", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtWeight.Focus();
                return;
            }
            Weight = weight;

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
