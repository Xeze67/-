using System;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace GroceryStoreApp
{
    public partial class Form1 : Form
    {
        // Поля для работы с базой данных Access
        private OleDbConnection connection;
        private OleDbDataAdapter dataAdapter;
        private OleDbCommandBuilder commandBuilder;
        private DataTable currentDataTable;
        private string currentDbTable = "Кассир";
        private string currentDisplayTitle = "Кассиры";
        private string connectionString;
        private string currentDatabasePath;

        public Form1()
        {
            InitializeComponent();
            this.FormClosing += Form1_FormClosing;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // Поиск файла базы данных Продуктовый.accdb
                currentDatabasePath = FindDatabasePath();

                if (string.IsNullOrEmpty(currentDatabasePath) || !File.Exists(currentDatabasePath))
                {
                    MessageBox.Show(
                        "Файл базы данных 'Продуктовый.accdb' не найден!\n\n" +
                        "Убедитесь, что файл базы данных находится в папке с программой или в корне проекта.",
                        "База данных не найдена",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    lblStatus.Text = "Ошибка: файл базы данных 'Продуктовый.accdb' не найден.";
                    return;
                }

                // Подключение к Access через OLE DB с автоопределением установленного провайдера (ACE 12.0 / ACE 16.0 / ACE 15.0)
                string[] providers = new string[] { "Microsoft.ACE.OLEDB.16.0", "Microsoft.ACE.OLEDB.12.0", "Microsoft.ACE.OLEDB.15.0" };
                bool connected = false;
                Exception lastEx = null;

                foreach (string prov in providers)
                {
                    try
                    {
                        connectionString = $@"Provider={prov};Data Source={currentDatabasePath};Persist Security Info=False;";
                        connection = new OleDbConnection(connectionString);
                        connection.Open();
                        connection.Close();
                        connected = true;
                        break;
                    }
                    catch (Exception ex)
                    {
                        lastEx = ex;
                    }
                }

                if (!connected)
                {
                    MessageBox.Show(
                        "Не удалось подключиться к базе данных Access через OLE DB.\n\n" +
                        "Текст ошибки:\n" + (lastEx != null ? lastEx.Message : "Провайдер OLE DB недоступен."),
                        "Ошибка подключения",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    lblStatus.Text = "Ошибка подключения к БД: " + (lastEx != null ? lastEx.Message : "");
                    return;
                }

                // Загружаем первую таблицу «Кассиры» при запуске
                LoadTable("Кассир", "Кассиры");

                lblStatus.Text = $"База данных подключена: {Path.GetFileName(currentDatabasePath)}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при запуске приложения:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "Ошибка: " + ex.Message;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                SyncDatabaseCopies();
            }
            catch
            {
            }
        }

        /// <summary>
        /// Поиск файла базы данных Продуктовый.accdb.
        /// В первую очередь подключается к основной базе в папке задания, чтобы изменения сразу были видны в Access.
        /// </summary>
        private string FindDatabasePath()
        {
            string[] searchPaths = new string[]
            {
                // Основной мастер-файл в корневой папке задания на рабочем столе
                @"C:\Users\грызлы 2.0\Desktop\Мдк Красноперов\Продуктовый.accdb",
                // На 3 уровня выше bin\Debug (корень Мдк Красноперов)
                Path.Combine(Application.StartupPath, @"..\..\..\Продуктовый.accdb"),
                // В каталоге проекта
                Path.Combine(Application.StartupPath, @"..\..\Продуктовый.accdb"),
                // В папке с запущенным exe (при автономном запуске без исходников / с флешки)
                Path.Combine(Application.StartupPath, "Продуктовый.accdb"),
                Path.Combine(Environment.CurrentDirectory, "Продуктовый.accdb")
            };

            foreach (string path in searchPaths)
            {
                if (File.Exists(path))
                {
                    return Path.GetFullPath(path);
                }
            }

            return null;
        }

        /// <summary>
        /// Синхронизация изменений во всех копиях базы данных на диске (в корне, в проекте и в bin\Debug),
        /// чтобы добавленные данные были видны и в Access, и в Visual Studio, и при перезапуске.
        /// </summary>
        private void SyncDatabaseCopies()
        {
            if (string.IsNullOrEmpty(currentDatabasePath) || !File.Exists(currentDatabasePath))
                return;

            string[] possibleCopies = new string[]
            {
                @"C:\Users\грызлы 2.0\Desktop\Мдк Красноперов\Продуктовый.accdb",
                Path.Combine(Application.StartupPath, "Продуктовый.accdb"),
                Path.Combine(Application.StartupPath, @"..\..\Продуктовый.accdb"),
                Path.Combine(Application.StartupPath, @"..\..\..\Продуктовый.accdb"),
                Path.Combine(Application.StartupPath, @"..\..\bin\Debug\Продуктовый.accdb"),
                Path.Combine(Application.StartupPath, @"..\..\bin\x86\Debug\Продуктовый.accdb"),
                Path.Combine(Application.StartupPath, @"..\..\bin\x64\Debug\Продуктовый.accdb")
            };

            foreach (string copyPath in possibleCopies)
            {
                try
                {
                    string fullCopy = Path.GetFullPath(copyPath);
                    string fullCurrent = Path.GetFullPath(currentDatabasePath);
                    if (!string.Equals(fullCopy, fullCurrent, StringComparison.OrdinalIgnoreCase))
                    {
                        string dir = Path.GetDirectoryName(fullCopy);
                        if (Directory.Exists(dir))
                        {
                            File.Copy(fullCurrent, fullCopy, true);
                        }
                    }
                }
                catch
                {
                    // Игнорируем заблокированные файлы
                }
            }
        }

        /// <summary>
        /// Загрузка выбранной таблицы из Access в DataGridView
        /// </summary>
        /// <param name="tableName">Название таблицы в файле Access</param>
        /// <param name="displayTitle">Отображаемое русское название таблицы</param>
        private void LoadTable(string tableName, string displayTitle)
        {
            try
            {
                currentDbTable = tableName;
                currentDisplayTitle = displayTitle;

                // Автоматически меняем заголовок над таблицей
                lblCurrentTable.Text = "Текущая таблица: " + displayTitle;

                string query = $"SELECT * FROM [{tableName}]";

                dataAdapter = new OleDbDataAdapter(query, connection);
                dataAdapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;

                // CommandBuilder автоматически строит команды INSERT, UPDATE, DELETE для Access
                commandBuilder = new OleDbCommandBuilder(dataAdapter);
                commandBuilder.QuotePrefix = "[";
                commandBuilder.QuoteSuffix = "]";

                currentDataTable = new DataTable();
                dataAdapter.Fill(currentDataTable);

                // Настройка автоинкремента и разрешения null для удобного ввода новых строк
                foreach (DataColumn col in currentDataTable.Columns)
                {
                    col.AllowDBNull = true;
                    if (col.DataType == typeof(int) && (col.ColumnName.ToLower().Contains("id") || col.ColumnName == "ID"))
                    {
                        col.AutoIncrement = true;
                        col.AutoIncrementSeed = -1;
                        col.AutoIncrementStep = -1;
                    }
                }

                // Привязка данных к сетке
                dataGridView1.DataSource = currentDataTable;
                dataGridView1.ScrollBars = ScrollBars.Both;

                // Настройка ширины колонок, чтобы текст не сжимался и появлялись полосы прокрутки
                foreach (DataGridViewColumn col in dataGridView1.Columns)
                {
                    col.MinimumWidth = 110;
                }
                dataGridView1.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

                lblStatus.Text = $"Таблица «{displayTitle}» загружена. Записей: {currentDataTable.Rows.Count}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке таблицы «{displayTitle}»:\n" + ex.Message,
                                "Ошибка загрузки", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "Ошибка загрузки: " + ex.Message;
            }
        }

        // =========================================================================
        // ОБРАБОТЧИКИ НАЖАТИЯ КНОПОК ПЕРЕКЛЮЧЕНИЯ ТАБЛИЦ
        // =========================================================================

        private void btnCashiers_Click(object sender, EventArgs e)
        {
            LoadTable("Кассир", "Кассиры");
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            LoadTable("Покупатель", "Покупатели");
        }

        private void btnCards_Click(object sender, EventArgs e)
        {
            LoadTable("КартаЛояльности", "Карты лояльности");
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            LoadTable("Товар", "Товары");
        }

        private void btnSales_Click(object sender, EventArgs e)
        {
            LoadTable("Продажа", "Продажи (чеки)");
        }

        private void btnSaleDetails_Click(object sender, EventArgs e)
        {
            LoadTable("СоставПродажи", "Состав чека");
        }

        /// <summary>
        /// Кнопка «Добавить товар» — открывает окно добавления нового товара и сразу сохраняет в базу Access
        /// </summary>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Переключаемся на таблицу "Товары"
            if (currentDbTable != "Товар")
            {
                LoadTable("Товар", "Товары");
            }

            using (FormAddProduct addForm = new FormAddProduct())
            {
                if (addForm.ShowDialog(this) == DialogResult.OK)
                {
                    try
                    {
                        // Вставляем новый товар напрямую в Access через SQL INSERT с параметрами
                        string insertQuery = "INSERT INTO [Товар] ([Штрихкод], [Наименование], [Цена], [Вес]) VALUES (?, ?, ?, ?)";
                        using (OleDbCommand cmd = new OleDbCommand(insertQuery, connection))
                        {
                            cmd.Parameters.Add("?", OleDbType.VarWChar, 20).Value = addForm.Barcode;
                            cmd.Parameters.Add("?", OleDbType.VarWChar, 150).Value = addForm.ItemName;
                            cmd.Parameters.Add("?", OleDbType.Currency).Value = addForm.Price;
                            cmd.Parameters.Add("?", OleDbType.Double).Value = addForm.Weight;

                            if (connection.State != ConnectionState.Open)
                                connection.Open();

                            cmd.ExecuteNonQuery();
                            connection.Close();
                        }

                        // Обновляем копии файла базы данных на диске
                        SyncDatabaseCopies();

                        // Обновляем отображение таблицы "Товары" в сетке
                        LoadTable("Товар", "Товары");

                        lblStatus.Text = $"Товар «{addForm.ItemName}» успешно сохранен в базу данных!";
                        MessageBox.Show(
                            $"Товар «{addForm.ItemName}» (штрихкод: {addForm.Barcode}) успешно сохранен в базу данных Access!",
                            "Товар сохранен",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        if (connection != null && connection.State == ConnectionState.Open)
                            connection.Close();

                        MessageBox.Show(
                            "Ошибка при сохранении товара в базу данных:\n" + ex.Message + "\n\n" +
                            "Возможно, товар с таким штрихкодом уже существует в базе.",
                            "Ошибка добавления",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                        lblStatus.Text = "Ошибка добавления: " + ex.Message;
                    }
                }
            }
        }

        // =========================================================================
        // ОБРАБОТЧИКИ КНОПОК ДЕЙСТВИЙ (СОХРАНИТЬ, УДАЛИТЬ, ВЫХОД)
        // =========================================================================

        /// <summary>
        /// Кнопка «Сохранить изменения» — применяет все добавленные, отредактированные и удаленные строки в Access
        /// </summary>
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // Завершаем редактирование текущей ячейки в сетке и фиксируем строку в таблице данных
                this.Validate();
                dataGridView1.EndEdit();
                if (currentDataTable != null)
                {
                    BindingContext[currentDataTable].EndCurrentEdit();
                }

                if (dataAdapter != null && currentDataTable != null)
                {
                    // Сохраняем изменения в Access
                    int affectedRows = dataAdapter.Update(currentDataTable);

                    // Синхронизируем все копии базы на диске
                    SyncDatabaseCopies();

                    // Перезагружаем таблицу, чтобы обновить автоинкрементные счетчики и актуальные данные
                    LoadTable(currentDbTable, currentDisplayTitle);

                    lblStatus.Text = $"Изменения в таблице «{currentDisplayTitle}» успешно сохранены. Обновлено строк: {affectedRows}";
                    MessageBox.Show(
                        $"Все изменения в таблице «{currentDisplayTitle}» успешно сохранены в базу данных Access!\n(Затронуто строк: {affectedRows})",
                        "Успешное сохранение",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Ошибка при сохранении изменений в базу данных:\n" + ex.Message + "\n\n" +
                    "Совет: проверьте правильность форматов введенных данных (числа, даты, обязательные поля, уникальность ключей).",
                    "Ошибка сохранения",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                lblStatus.Text = "Ошибка сохранения: " + ex.Message;
            }
        }

        /// <summary>
        /// Кнопка «Удалить запись» — удаляет выбранную строку из текущей таблицы и сразу обновляет базу Access
        /// </summary>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.IsNewRow)
                {
                    MessageBox.Show("Пожалуйста, выделите строку для удаления.", "Удаление", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult result = MessageBox.Show(
                    "Вы действительно хотите удалить выбранную запись из базы данных?",
                    "Подтверждение удаления",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);

                    if (dataAdapter != null && currentDataTable != null)
                    {
                        dataAdapter.Update(currentDataTable);
                        SyncDatabaseCopies();
                    }

                    lblStatus.Text = "Запись успешно удалена из базы данных Access.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при удалении записи:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Кнопка «Выход» — закрытие программы с подтверждением
        /// </summary>
        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Вы уверены, что хотите выйти из приложения?",
                "Выход из программы",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void panelMenu_Paint(object sender, PaintEventArgs e)
        {
            // Метод оставлен для поддержки дизайнера
        }
    }
}
