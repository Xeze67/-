using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace GroceryStoreOnline
{
    public class FormBuyer : Form
    {
        private User currentUser;
        private string cardNumber = "";
        private int bonusBalance = 0;

        private List<CartItem> cart = new List<CartItem>();

        // Элементы шапки
        private Label lblCustomerInfo;
        private Label lblCardInfo;
        private Button btnMyOrdersTop;
        private Button btnLogout;

        // Основной сплиттер (каталог слева, корзина справа)
        private SplitContainer splitMain;

        // Элементы каталога
        private TextBox txtSearch;
        private DataGridView dgvCatalog;
        private NumericUpDown numQuantity;
        private Button btnAddToCart;

        // Элементы корзины
        private Label lblCartTitle;
        private DataGridView dgvCart;
        private Button btnRemoveFromCart;
        private Button btnClearCart;
        private Label lblTotal;

        // Элементы оформления заказа
        private TextBox txtDeliveryAddress;
        private ComboBox cmbPayment;
        private RadioButton rbBonusAccrue;
        private RadioButton rbBonusSpend;
        private NumericUpDown numBonusesToSpend;
        private Label lblBonusAvailable;
        private Label lblCheckoutSubtotal;
        private Label lblCheckoutDiscount;
        private Label lblCheckoutTotal;
        private Button btnOrder;

        public FormBuyer(User user)
        {
            this.currentUser = user;
            InitializeComponent();
            this.Load += FormBuyer_Load;
        }

        private void FormBuyer_Load(object sender, EventArgs e)
        {
            LoadUserData();
            LoadCatalog();
            RefreshCartGrid();

            // Обеспечиваем ровно 50% / 50% разделение между каталогом и корзиной при любой ширине
            try
            {
                if (splitMain != null && splitMain.Width > 200)
                {
                    splitMain.SplitterDistance = splitMain.Width / 2;
                }
            }
            catch { }
        }

        private void InitializeComponent()
        {
            this.Text = "Онлайн-маркет «Продуктовый» — Личный кабинет покупателя";
            // Оптимальный размер: комфортно помещается на экране 1024x768 и масштабируется
            this.Size = new Size(1015, 675);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MinimumSize = new Size(880, 560);
            this.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(204)));
            this.BackColor = Color.FromArgb(244, 246, 249);

            // ==========================================
            // 1. ВЕРХНЯЯ ШАПКА
            // ==========================================
            Panel pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                BackColor = Color.FromArgb(25, 118, 210)
            };

            lblCustomerInfo = new Label
            {
                Location = new Point(15, 8),
                AutoSize = true,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold)
            };

            lblCardInfo = new Label
            {
                Location = new Point(15, 33),
                AutoSize = true,
                ForeColor = Color.FromArgb(227, 242, 253),
                Font = new Font("Segoe UI", 9F)
            };

            Panel pnlHeaderRight = new Panel
            {
                Dock = DockStyle.Right,
                Width = 270,
                BackColor = Color.Transparent
            };

            btnMyOrdersTop = new Button
            {
                Text = "Мои заказы",
                Location = new Point(10, 14),
                Size = new Size(140, 32),
                BackColor = Color.FromArgb(238, 238, 238),
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnMyOrdersTop.FlatAppearance.BorderColor = Color.LightGray;
            btnMyOrdersTop.Click += BtnMyOrders_Click;

            btnLogout = new Button
            {
                Text = "Выход",
                Location = new Point(160, 14),
                Size = new Size(95, 32),
                BackColor = Color.FromArgb(211, 47, 47),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.Click += (s, e) => { this.Close(); };

            pnlHeaderRight.Controls.Add(btnMyOrdersTop);
            pnlHeaderRight.Controls.Add(btnLogout);

            pnlHeader.Controls.Add(pnlHeaderRight);
            pnlHeader.Controls.Add(lblCustomerInfo);
            pnlHeader.Controls.Add(lblCardInfo);
            this.Controls.Add(pnlHeader);

            // ==========================================
            // 2. НИЖНЯЯ ПАНЕЛЬ ОФОРМЛЕНИЯ ЗАКАЗА (СО СДЕЛАТЬ ЗАКАЗ)
            // ==========================================
            TableLayoutPanel tlpCheckout = new TableLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 145,
                ColumnCount = 2,
                RowCount = 1,
                BackColor = Color.White,
                Padding = new Padding(10, 4, 10, 4)
            };
            tlpCheckout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tlpCheckout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 280F));
            tlpCheckout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlpCheckout.Paint += (s, e) =>
            {
                e.Graphics.DrawLine(new Pen(Color.FromArgb(220, 224, 230), 1), 0, 0, tlpCheckout.Width, 0);
            };

            // Левая часть оформления заказа: адрес доставки, способ оплаты и бонусы
            Panel pnlCheckoutLeft = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White
            };

            Label lblAddr = new Label
            {
                Text = "Куда везти (Адрес доставки):",
                Location = new Point(4, 3),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };

            txtDeliveryAddress = new TextBox
            {
                Location = new Point(4, 24),
                Height = 25,
                Font = new Font("Segoe UI", 9.5F)
            };

            Label lblPay = new Label
            {
                Text = "Способ оплаты:",
                Location = new Point(4, 55),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };

            cmbPayment = new ComboBox
            {
                Location = new Point(4, 78),
                Width = 240,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 9.5F)
            };
            cmbPayment.Items.AddRange(new object[] {
                "Банковская карта онлайн",
                "Оплата через СБП (QR-код)",
                "Банковской картой при получении",
                "Наличными курьеру при получении"
            });
            cmbPayment.SelectedIndex = 0;

            // Блок бонусов программы лояльности
            Label lblLoyaltyHeader = new Label
            {
                Text = "Бонусы карты лояльности:",
                Location = new Point(260, 55),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };

            rbBonusAccrue = new RadioButton
            {
                Text = "Начислить +3% бонусов",
                Location = new Point(260, 78),
                AutoSize = true,
                Checked = true,
                Font = new Font("Segoe UI", 9F)
            };
            rbBonusAccrue.CheckedChanged += (s, e) =>
            {
                if (rbBonusAccrue.Checked)
                {
                    numBonusesToSpend.Enabled = false;
                    numBonusesToSpend.Value = 0;
                    RefreshCartGrid();
                }
            };

            rbBonusSpend = new RadioButton
            {
                Text = "Списать в скидку:",
                Location = new Point(260, 103),
                AutoSize = true,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(46, 125, 50)
            };
            rbBonusSpend.CheckedChanged += (s, e) =>
            {
                if (rbBonusSpend.Checked)
                {
                    numBonusesToSpend.Enabled = true;
                    decimal raw = 0;
                    foreach (var itm in cart) raw += itm.Total;
                    int maxSpend = Math.Min(bonusBalance, (int)raw);
                    numBonusesToSpend.Maximum = bonusBalance;
                    numBonusesToSpend.Value = maxSpend;
                    RefreshCartGrid();
                }
            };

            numBonusesToSpend = new NumericUpDown
            {
                Location = new Point(395, 102),
                Width = 65,
                Minimum = 0,
                Maximum = 999999,
                Value = 0,
                Enabled = false,
                Font = new Font("Segoe UI", 9F)
            };
            numBonusesToSpend.ValueChanged += (s, e) =>
            {
                RefreshCartGrid();
            };

            lblBonusAvailable = new Label
            {
                Text = "(доступно: 0 баллов)",
                Location = new Point(465, 104),
                AutoSize = true,
                Font = new Font("Segoe UI", 8.5F, FontStyle.Italic),
                ForeColor = Color.FromArgb(100, 116, 139)
            };

            // Автоматическое расширение поля адреса по всей ширине
            pnlCheckoutLeft.Resize += (s, e) =>
            {
                txtDeliveryAddress.Width = Math.Max(240, pnlCheckoutLeft.ClientSize.Width - 12);
            };

            pnlCheckoutLeft.Controls.Add(lblAddr);
            pnlCheckoutLeft.Controls.Add(txtDeliveryAddress);
            pnlCheckoutLeft.Controls.Add(lblPay);
            pnlCheckoutLeft.Controls.Add(cmbPayment);
            pnlCheckoutLeft.Controls.Add(lblLoyaltyHeader);
            pnlCheckoutLeft.Controls.Add(rbBonusAccrue);
            pnlCheckoutLeft.Controls.Add(rbBonusSpend);
            pnlCheckoutLeft.Controls.Add(numBonusesToSpend);
            pnlCheckoutLeft.Controls.Add(lblBonusAvailable);

            // Правая часть оформления заказа: КНОПКА «СДЕЛАТЬ ЗАКАЗ» (В отдельной защищенной колонке 280px)
            Panel pnlCheckoutRight = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White
            };

            lblCheckoutSubtotal = new Label
            {
                Text = "Товаров: 0,00 руб.",
                Location = new Point(4, 4),
                Size = new Size(270, 18),
                Font = new Font("Segoe UI", 9F),
                ForeColor = Color.FromArgb(100, 116, 139),
                TextAlign = ContentAlignment.MiddleRight
            };

            lblCheckoutDiscount = new Label
            {
                Text = "Скидка бонусами: -0,00 руб.",
                Location = new Point(4, 22),
                Size = new Size(270, 18),
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(46, 125, 50),
                TextAlign = ContentAlignment.MiddleRight,
                Visible = false
            };

            lblCheckoutTotal = new Label
            {
                Text = "ИТОГО К ОПЛАТЕ: 0,00 руб.",
                Location = new Point(4, 40),
                Size = new Size(270, 24),
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(198, 40, 40),
                TextAlign = ContentAlignment.MiddleRight
            };

            btnOrder = new Button
            {
                Text = "СДЕЛАТЬ ЗАКАЗ",
                Location = new Point(4, 68),
                Size = new Size(270, 58),
                BackColor = Color.FromArgb(230, 81, 0), // Заметный сочный оранжевый цвет
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnOrder.FlatAppearance.BorderSize = 0;
            btnOrder.Click += BtnOrder_Click;

            pnlCheckoutRight.Controls.Add(lblCheckoutSubtotal);
            pnlCheckoutRight.Controls.Add(lblCheckoutDiscount);
            pnlCheckoutRight.Controls.Add(lblCheckoutTotal);
            pnlCheckoutRight.Controls.Add(btnOrder);

            tlpCheckout.Controls.Add(pnlCheckoutLeft, 0, 0);
            tlpCheckout.Controls.Add(pnlCheckoutRight, 1, 0);

            this.Controls.Add(tlpCheckout);

            // ==========================================
            // 3. ОСНОВНАЯ ОБЛАСТЬ (КАТАЛОГ СЛЕВА, КОРЗИНА СПРАВА)
            // ==========================================
            splitMain = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                SplitterDistance = 490,
                Padding = new Padding(8, 6, 8, 4)
            };
            splitMain.Resize += (s, e) =>
            {
                try
                {
                    if (splitMain.Width > 200)
                        splitMain.SplitterDistance = splitMain.Width / 2;
                }
                catch { }
            };
            this.Controls.Add(splitMain);

            // ------------------ ЛЕВАЯ ПАНЕЛЬ: КАТАЛОГ ТОВАРОВ ------------------
            Panel pnlCatalogHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 36
            };

            Label lblCatTitle = new Label
            {
                Text = "Каталог товаров магазина:",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Location = new Point(4, 8),
                AutoSize = true
            };

            Panel pnlCatSearch = new Panel
            {
                Dock = DockStyle.Right,
                Width = 230,
                BackColor = Color.Transparent
            };

            Label lblSearchPrompt = new Label
            {
                Text = "Поиск:",
                Location = new Point(4, 8),
                AutoSize = true
            };

            txtSearch = new TextBox
            {
                Location = new Point(55, 6),
                Width = 168
            };
            txtSearch.TextChanged += (s, e) => { LoadCatalog(txtSearch.Text.Trim()); };

            pnlCatSearch.Controls.Add(lblSearchPrompt);
            pnlCatSearch.Controls.Add(txtSearch);

            pnlCatalogHeader.Controls.Add(pnlCatSearch);
            pnlCatalogHeader.Controls.Add(lblCatTitle);

            // Нижняя панель каталога: кнопка добавления в корзину
            Panel pnlCatalogBottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 44,
                Padding = new Padding(4)
            };

            Label lblQty = new Label
            {
                Text = "Кол-во:",
                Location = new Point(4, 12),
                AutoSize = true,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold)
            };

            numQuantity = new NumericUpDown
            {
                Location = new Point(60, 10),
                Width = 50,
                Minimum = 1,
                Maximum = 99,
                Value = 1,
                Font = new Font("Segoe UI", 9.5F)
            };

            btnAddToCart = new Button
            {
                Text = "Добавить в корзину",
                Location = new Point(120, 6),
                Size = new Size(185, 32),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnAddToCart.FlatAppearance.BorderSize = 0;
            btnAddToCart.Click += BtnAddToCart_Click;

            Label lblHintDblClick = new Label
            {
                Text = "(или 2 клика)",
                Location = new Point(310, 12),
                AutoSize = true,
                ForeColor = Color.DimGray,
                Font = new Font("Segoe UI", 8.5F, FontStyle.Italic)
            };

            pnlCatalogBottom.Controls.Add(lblQty);
            pnlCatalogBottom.Controls.Add(numQuantity);
            pnlCatalogBottom.Controls.Add(btnAddToCart);
            pnlCatalogBottom.Controls.Add(lblHintDblClick);

            dgvCatalog = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                ScrollBars = ScrollBars.Both
            };
            dgvCatalog.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) AddCurrentCatalogItem(); };
            dgvCatalog.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space)
                {
                    e.Handled = true;
                    AddCurrentCatalogItem();
                }
            };

            splitMain.Panel1.Controls.Add(dgvCatalog);
            splitMain.Panel1.Controls.Add(pnlCatalogBottom);
            splitMain.Panel1.Controls.Add(pnlCatalogHeader);
            pnlCatalogHeader.SendToBack();
            pnlCatalogBottom.SendToBack();
            dgvCatalog.BringToFront();

            // ------------------ ПРАВАЯ ПАНЕЛЬ: КОРЗИНА ПОКУПАТЕЛЯ ------------------
            Panel pnlCartHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 34
            };
            lblCartTitle = new Label
            {
                Text = "Корзина покупателя:",
                Font = new Font("Segoe UI", 10.5F, FontStyle.Bold),
                Location = new Point(4, 6),
                AutoSize = true
            };
            pnlCartHeader.Controls.Add(lblCartTitle);

            Panel pnlCartBottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 44,
                Padding = new Padding(4)
            };

            btnRemoveFromCart = new Button
            {
                Text = "Удалить товар",
                Location = new Point(4, 6),
                Size = new Size(115, 32),
                BackColor = Color.FromArgb(240, 240, 240),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnRemoveFromCart.FlatAppearance.BorderColor = Color.LightGray;
            btnRemoveFromCart.Click += BtnRemoveFromCart_Click;

            btnClearCart = new Button
            {
                Text = "Очистить всё",
                Location = new Point(125, 6),
                Size = new Size(105, 32),
                BackColor = Color.FromArgb(240, 240, 240),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnClearCart.FlatAppearance.BorderColor = Color.LightGray;
            btnClearCart.Click += (s, e) => { cart.Clear(); RefreshCartGrid(); };

            lblTotal = new Label
            {
                Text = "ИТОГО: 0,00 руб.",
                Font = new Font("Segoe UI", 10.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(198, 40, 40),
                TextAlign = ContentAlignment.MiddleRight,
                Size = new Size(220, 26)
            };

            pnlCartBottom.Resize += (s, e) =>
            {
                lblTotal.Location = new Point(Math.Max(240, pnlCartBottom.ClientSize.Width - lblTotal.Width - 10), 9);
            };

            pnlCartBottom.Controls.Add(btnRemoveFromCart);
            pnlCartBottom.Controls.Add(btnClearCart);
            pnlCartBottom.Controls.Add(lblTotal);

            dgvCart = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                ScrollBars = ScrollBars.Both
            };

            splitMain.Panel2.Controls.Add(dgvCart);
            splitMain.Panel2.Controls.Add(pnlCartBottom);
            splitMain.Panel2.Controls.Add(pnlCartHeader);
            pnlCartHeader.SendToBack();
            pnlCartBottom.SendToBack();
            dgvCart.BringToFront();

            // Порядок слоев формы
            pnlHeader.SendToBack();
            tlpCheckout.SendToBack();
            splitMain.BringToFront();
        }

        private void LoadUserData()
        {
            lblCustomerInfo.Text = $"Здравствуйте, {currentUser.FullName}! (Логин: {currentUser.Login})";
            txtDeliveryAddress.Text = currentUser.Address;

            if (DbHelper.GetBuyerCard(currentUser.CustomerId, out cardNumber, out bonusBalance))
            {
                lblCardInfo.Text = $"Карта лояльности: {cardNumber} | Доступно бонусов: {bonusBalance} баллов";
                rbBonusAccrue.Text = $"Начислить +3% бонусов ({cardNumber})";
                rbBonusAccrue.Enabled = true;

                rbBonusSpend.Enabled = (bonusBalance > 0);
                numBonusesToSpend.Maximum = bonusBalance;
                numBonusesToSpend.Value = 0;
                numBonusesToSpend.Enabled = false;
                lblBonusAvailable.Text = $"(доступно: {bonusBalance} баллов)";
            }
            else
            {
                lblCardInfo.Text = "Карта лояльности не привязана";
                rbBonusAccrue.Text = "Карта лояльности отсутствует";
                rbBonusAccrue.Enabled = false;
                rbBonusSpend.Enabled = false;
                numBonusesToSpend.Enabled = false;
                lblBonusAvailable.Text = "(0 баллов)";
            }
        }

        private void LoadCatalog(string search = "")
        {
            try
            {
                DataTable dt = DbHelper.GetProducts(search);
                dgvCatalog.DataSource = dt;

                if (dgvCatalog.Columns["Штрихкод"] != null)
                {
                    dgvCatalog.Columns["Штрихкод"].HeaderText = "Штрихкод";
                    dgvCatalog.Columns["Штрихкод"].Width = 110;
                }
                if (dgvCatalog.Columns["Наименование"] != null)
                {
                    dgvCatalog.Columns["Наименование"].HeaderText = "Наименование товара";
                    dgvCatalog.Columns["Наименование"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
                if (dgvCatalog.Columns["Цена"] != null)
                {
                    dgvCatalog.Columns["Цена"].HeaderText = "Цена (руб.)";
                    dgvCatalog.Columns["Цена"].Width = 90;
                    dgvCatalog.Columns["Цена"].DefaultCellStyle.Format = "N2";
                    dgvCatalog.Columns["Цена"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
                if (dgvCatalog.Columns["Вес"] != null)
                {
                    dgvCatalog.Columns["Вес"].HeaderText = "Вес (кг)";
                    dgvCatalog.Columns["Вес"].Width = 80;
                    dgvCatalog.Columns["Вес"].DefaultCellStyle.Format = "N2";
                    dgvCatalog.Columns["Вес"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }

                if (dgvCatalog.Rows.Count > 0)
                {
                    try
                    {
                        dgvCatalog.CurrentCell = dgvCatalog.Rows[0].Cells[1];
                    }
                    catch { }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке каталога продуктов:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnAddToCart_Click(object sender, EventArgs e)
        {
            AddCurrentCatalogItem();
        }

        private void AddCurrentCatalogItem()
        {
            DataGridViewRow row = dgvCatalog.CurrentRow;
            if (row == null && dgvCatalog.Rows.Count > 0)
            {
                row = dgvCatalog.Rows[0];
            }

            if (row == null)
            {
                MessageBox.Show("Пожалуйста, выберите товар из каталога для добавления в корзину!", "Выберите товар", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string barcode = row.Cells["Штрихкод"].Value.ToString();
            string name = row.Cells["Наименование"].Value.ToString();
            decimal price = Convert.ToDecimal(row.Cells["Цена"].Value);
            int qty = (int)numQuantity.Value;
            if (qty <= 0) qty = 1;

            CartItem existing = cart.Find(item => item.Barcode == barcode);
            if (existing != null)
            {
                existing.Quantity += qty;
            }
            else
            {
                cart.Add(new CartItem
                {
                    Barcode = barcode,
                    Name = name,
                    Price = price,
                    Quantity = qty
                });
            }

            RefreshCartGrid();
            numQuantity.Value = 1;
        }

        private void BtnRemoveFromCart_Click(object sender, EventArgs e)
        {
            if (dgvCart.CurrentRow != null && dgvCart.CurrentRow.Index >= 0 && dgvCart.CurrentRow.Index < cart.Count)
            {
                cart.RemoveAt(dgvCart.CurrentRow.Index);
                RefreshCartGrid();
            }
        }

        private void RefreshCartGrid()
        {
            DataTable dtCart = new DataTable();
            dtCart.Columns.Add("Наименование товара");
            dtCart.Columns.Add("Цена за шт.", typeof(decimal));
            dtCart.Columns.Add("Кол-во", typeof(int));
            dtCart.Columns.Add("Стоимость", typeof(decimal));

            decimal total = 0;
            int totalPieces = 0;
            foreach (var item in cart)
            {
                dtCart.Rows.Add(item.Name, item.Price, item.Quantity, item.Total);
                total += item.Total;
                totalPieces += item.Quantity;
            }

            dgvCart.DataSource = dtCart;

            if (dgvCart.Columns["Наименование товара"] != null)
            {
                dgvCart.Columns["Наименование товара"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }
            if (dgvCart.Columns["Цена за шт."] != null)
            {
                dgvCart.Columns["Цена за шт."].DefaultCellStyle.Format = "N2";
                dgvCart.Columns["Цена за шт."].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvCart.Columns["Цена за шт."].Width = 85;
            }
            if (dgvCart.Columns["Кол-во"] != null)
            {
                dgvCart.Columns["Кол-во"].Width = 60;
                dgvCart.Columns["Кол-во"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
            if (dgvCart.Columns["Стоимость"] != null)
            {
                dgvCart.Columns["Стоимость"].DefaultCellStyle.Format = "N2";
                dgvCart.Columns["Стоимость"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvCart.Columns["Стоимость"].Width = 90;
            }

            decimal discount = 0;
            if (rbBonusSpend != null && rbBonusSpend.Checked && numBonusesToSpend.Enabled)
            {
                int maxSpend = Math.Min(bonusBalance, (int)total);
                numBonusesToSpend.Maximum = Math.Max(0, maxSpend);
                int spend = (int)numBonusesToSpend.Value;
                if (spend > maxSpend)
                {
                    spend = maxSpend;
                    numBonusesToSpend.Value = spend;
                }
                discount = spend;
            }

            decimal finalPayable = Math.Max(0m, total - discount);

            lblTotal.Text = $"ИТОГО: {total:N2} руб.";
            lblCheckoutSubtotal.Text = $"Товаров: {total:N2} руб.";

            if (discount > 0)
            {
                lblCheckoutDiscount.Text = $"Скидка бонусами: -{discount:N2} руб.";
                lblCheckoutDiscount.Visible = true;
            }
            else
            {
                lblCheckoutDiscount.Visible = false;
            }

            lblCheckoutTotal.Text = $"ИТОГО К ОПЛАТЕ: {finalPayable:N2} руб.";
            lblCartTitle.Text = $"Корзина покупателя ({cart.Count} поз., {totalPieces} шт.):";
        }

        private void BtnOrder_Click(object sender, EventArgs e)
        {
            if (cart.Count == 0)
            {
                MessageBox.Show("Ваша корзина пуста! Пожалуйста, добавьте товары из каталога с помощью кнопки «Добавить в корзину».", "Корзина пуста", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string address = txtDeliveryAddress.Text.Trim();
            if (!DbHelper.IsValidDeliveryAddress(address, out string addrErr))
            {
                MessageBox.Show(addrErr, "Некорректный адрес доставки", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtDeliveryAddress.Focus();
                return;
            }

            string payment = cmbPayment.SelectedItem != null ? cmbPayment.SelectedItem.ToString() : "Банковская карта онлайн";
            string cardToUse = !string.IsNullOrEmpty(cardNumber) ? cardNumber : null;

            int spendBonuses = 0;
            if (rbBonusSpend != null && rbBonusSpend.Checked && numBonusesToSpend.Enabled)
            {
                spendBonuses = (int)numBonusesToSpend.Value;
            }

            int newOrderId;
            string error;
            bool ok = DbHelper.CreateOrder(currentUser, address, payment, cardToUse, spendBonuses, cart, out newOrderId, out error);

            if (!ok)
            {
                MessageBox.Show(error, "Ошибка при оформлении", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            decimal rawSum = 0;
            foreach (var itm in cart) rawSum += itm.Total;
            decimal discount = Math.Min((decimal)spendBonuses, rawSum);
            decimal paidSum = rawSum - discount;

            string bonusMsg = "";
            if (!string.IsNullOrEmpty(cardToUse))
            {
                if (spendBonuses > 0)
                {
                    bonusMsg = $"\nСписано бонусов: {spendBonuses} баллов (скидка {discount:N2} руб.)";
                }
                else
                {
                    int earned = (int)(paidSum * 0.03m);
                    bonusMsg = $"\nВам начислено {earned} бонусов на карту {cardToUse}!";
                }
            }

            MessageBox.Show(
                $"Заказ №{newOrderId} успешно оформлен!\n\n" +
                $"Покупатель: {currentUser.FullName}\n" +
                $"Сумма товаров: {rawSum:N2} руб.\n" +
                (discount > 0 ? $"Скидка бонусами: -{discount:N2} руб.\n" : "") +
                $"ИТОГО К ОПЛАТЕ: {paidSum:N2} руб.\n" +
                $"Куда везти: {address}\n" +
                $"Способ оплаты: {payment}" +
                bonusMsg + "\n\n" +
                "Заказ сохранен за вашим аккаунтом со статусом «Новый» и сразу передан в панель администратора для доставки!",
                "Заказ оформлен",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            cart.Clear();
            if (rbBonusAccrue != null) rbBonusAccrue.Checked = true;
            RefreshCartGrid();
            LoadUserData();
        }

        private void BtnMyOrders_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = DbHelper.GetBuyerOrders(currentUser.CustomerId);
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("У вас пока нет оформленных заказов.", "История заказов", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                Form historyForm = new Form
                {
                    Text = $"История заказов покупателя {currentUser.FullName}",
                    Size = new Size(820, 460),
                    StartPosition = FormStartPosition.CenterParent,
                    Font = new Font("Segoe UI", 9F)
                };

                DataGridView dgvHistory = new DataGridView
                {
                    Dock = DockStyle.Fill,
                    DataSource = dt,
                    ReadOnly = true,
                    AllowUserToAddRows = false,
                    BackgroundColor = Color.White,
                    RowHeadersVisible = false,
                    SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                    AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                    ScrollBars = ScrollBars.Both
                };

                historyForm.Controls.Add(dgvHistory);

                if (dgvHistory.Columns["OrderId"] != null) { dgvHistory.Columns["OrderId"].HeaderText = "№ заказа"; dgvHistory.Columns["OrderId"].Width = 75; }
                if (dgvHistory.Columns["OrderDate"] != null) { dgvHistory.Columns["OrderDate"].HeaderText = "Дата и время"; dgvHistory.Columns["OrderDate"].Width = 135; }
                if (dgvHistory.Columns["DeliveryAddress"] != null) { dgvHistory.Columns["DeliveryAddress"].HeaderText = "Куда везти (Адрес доставки)"; dgvHistory.Columns["DeliveryAddress"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill; }
                if (dgvHistory.Columns["TotalSum"] != null)
                {
                    dgvHistory.Columns["TotalSum"].HeaderText = "Сумма (руб.)";
                    dgvHistory.Columns["TotalSum"].Width = 110;
                    dgvHistory.Columns["TotalSum"].DefaultCellStyle.Format = "N2";
                    dgvHistory.Columns["TotalSum"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
                if (dgvHistory.Columns["PaymentType"] != null) { dgvHistory.Columns["PaymentType"].HeaderText = "Способ оплаты"; dgvHistory.Columns["PaymentType"].Width = 150; }
                if (dgvHistory.Columns["OrderStatus"] != null)
                {
                    dgvHistory.Columns["OrderStatus"].HeaderText = "Статус";
                    dgvHistory.Columns["OrderStatus"].Width = 100;
                    dgvHistory.Columns["OrderStatus"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }

                historyForm.ShowDialog(this);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке истории заказов:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
