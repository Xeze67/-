using System;
using System.Windows.Forms;

namespace GroceryStoreOnline
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения онлайн-магазина.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormAuth());
        }
    }
}
