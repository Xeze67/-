using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GroceryStoreOnline")]
[assembly: AssemblyDescription("Онлайн-магазин продуктов питания — Клиентский модуль и модуль администратора")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("GroceryStoreOnline")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("e88f96c1-2854-4b29-b1a2-83fd73d4925a")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
