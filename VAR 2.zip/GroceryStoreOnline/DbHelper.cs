using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;

namespace GroceryStoreOnline
{
    public class User
    {
        public int Id { get; set; }
        public string Login { get; set; }
        public string Role { get; set; } // "Admin" или "Buyer"
        public int CustomerId { get; set; }
        public string FullName { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
    }

    public class CartItem
    {
        public string Barcode { get; set; }
        public string Name { get; set; }
        public string ProductName
        {
            get => Name;
            set => Name = value;
        }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public decimal Total => Price * Quantity;
    }

    public static class DbHelper
    {
        private static string connectionString = null;
        private static string dbFilePath = null;

        public static string GetDatabasePath()
        {
            if (!string.IsNullOrEmpty(dbFilePath) && File.Exists(dbFilePath))
                return dbFilePath;

            string[] searchPaths = new string[]
            {
                @"c:\Users\грызлы 2.0\Desktop\Мдк Красноперов\Продуктовый.accdb",
                Path.Combine(Application.StartupPath, "Продуктовый.accdb"),
                Path.Combine(Application.StartupPath, @"..\..\..\Продуктовый.accdb"),
                Path.Combine(Application.StartupPath, @"..\..\Продуктовый.accdb"),
                Path.Combine(Application.StartupPath, @"..\Продуктовый.accdb"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Продуктовый.accdb"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\Продуктовый.accdb")
            };

            foreach (string p in searchPaths)
            {
                try
                {
                    string full = Path.GetFullPath(p);
                    if (File.Exists(full))
                    {
                        dbFilePath = full;
                        return full;
                    }
                }
                catch { }
            }

            return @"c:\Users\грызлы 2.0\Desktop\Мдк Красноперов\Продуктовый.accdb";
        }

        public static OleDbConnection GetConnection()
        {
            if (string.IsNullOrEmpty(connectionString))
            {
                string dbPath = GetDatabasePath();
                string[] providers = new string[] { "Microsoft.ACE.OLEDB.16.0", "Microsoft.ACE.OLEDB.12.0", "Microsoft.ACE.OLEDB.15.0" };
                foreach (string prov in providers)
                {
                    try
                    {
                        string testConnStr = $@"Provider={prov};Data Source={dbPath};Persist Security Info=False;";
                        using (OleDbConnection testConn = new OleDbConnection(testConnStr))
                        {
                            testConn.Open();
                            testConn.Close();
                            connectionString = testConnStr;
                            break;
                        }
                    }
                    catch { }
                }

                if (string.IsNullOrEmpty(connectionString))
                {
                    connectionString = $@"Provider=Microsoft.ACE.OLEDB.16.0;Data Source={dbPath};Persist Security Info=False;";
                }
            }

            OleDbConnection conn = new OleDbConnection(connectionString);
            conn.Open();
            return conn;
        }

        public static void SyncCopies()
        {
            try
            {
                string mainPath = GetDatabasePath();
                if (!File.Exists(mainPath)) return;

                string fullMain = Path.GetFullPath(mainPath);

                // Поднимаемся до корневой папки задания "Мдк Красноперов"
                DirectoryInfo currentDir = new DirectoryInfo(Path.GetDirectoryName(fullMain));
                while (currentDir != null && !currentDir.Name.Contains("Красноперов") && currentDir.Parent != null)
                {
                    currentDir = currentDir.Parent;
                }
                if (currentDir == null) currentDir = new DirectoryInfo(@"c:\Users\грызлы 2.0\Desktop\Мдк Красноперов");

                if (currentDir.Exists)
                {
                    FileInfo[] allDbs = currentDir.GetFiles("Продуктовый.accdb", SearchOption.AllDirectories);
                    foreach (var fi in allDbs)
                    {
                        try
                        {
                            if (!string.Equals(fi.FullName, fullMain, StringComparison.OrdinalIgnoreCase))
                            {
                                File.Copy(fullMain, fi.FullName, true);
                            }
                        }
                        catch { }
                    }
                }
            }
            catch { }
        }

        // ==========================================
        // АВТОРИЗАЦИЯ И РЕГИСТРАЦИЯ
        // ==========================================

        public static User Authenticate(string login, string password, string expectedRole = null)
        {
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
                return null;

            login = login.Trim();
            password = password.Trim();

            using (OleDbConnection conn = GetConnection())
            {
                string sql = "SELECT [ID], [Логин], [Пароль], [Роль], [ID_Покупателя], [ФИО], [НомерТелефона], [АдресДоставки] " +
                             "FROM [Пользователь] WHERE StrComp([Логин], ?, 1) = 0 AND StrComp([Пароль], ?, 0) = 0";

                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = login;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = password;

                    using (OleDbDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string role = reader["Роль"].ToString();
                            if (!string.IsNullOrEmpty(expectedRole) && !string.Equals(role, expectedRole, StringComparison.OrdinalIgnoreCase))
                            {
                                return null;
                            }

                            int custId = 0;
                            if (reader["ID_Покупателя"] != DBNull.Value)
                                custId = Convert.ToInt32(reader["ID_Покупателя"]);

                            return new User
                            {
                                Id = Convert.ToInt32(reader["ID"]),
                                Login = reader["Логин"].ToString(),
                                Role = role,
                                CustomerId = custId,
                                FullName = reader["ФИО"] != DBNull.Value ? reader["ФИО"].ToString() : login,
                                Phone = reader["НомерТелефона"] != DBNull.Value ? reader["НомерТелефона"].ToString() : "",
                                Address = reader["АдресДоставки"] != DBNull.Value ? reader["АдресДоставки"].ToString() : ""
                            };
                        }
                    }
                }
            }
            return null;
        }

        public static User RegisterBuyer(string login, string password, string fio, string phone, string address, out string error)
        {
            error = "";
            login = login.Trim();
            password = password.Trim();
            fio = fio.Trim();
            phone = phone.Trim();
            address = address.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(fio))
            {
                error = "Пожалуйста, укажите ФИО, логин и пароль!";
                return null;
            }

            using (OleDbConnection conn = GetConnection())
            {
                // 1. Проверяем уникальность логина
                using (OleDbCommand checkCmd = new OleDbCommand("SELECT COUNT(*) FROM [Пользователь] WHERE StrComp([Логин], ?, 1) = 0", conn))
                {
                    checkCmd.Parameters.Add("?", OleDbType.VarWChar).Value = login;
                    int count = Convert.ToInt32(checkCmd.ExecuteScalar());
                    if (count > 0)
                    {
                        error = "Пользователь с таким логином уже зарегистрирован! Пожалуйста, выберите другой логин.";
                        return null;
                    }
                }

                // 2. Создаем запись в таблице Покупатель
                int newCustomerId = 1;
                using (OleDbCommand custCmd = new OleDbCommand("INSERT INTO [Покупатель] ([ФИО], [НомерТелефона]) VALUES (?, ?)", conn))
                {
                    custCmd.Parameters.Add("?", OleDbType.VarWChar).Value = fio;
                    custCmd.Parameters.Add("?", OleDbType.VarWChar).Value = phone;
                    custCmd.ExecuteNonQuery();
                }

                using (OleDbCommand idCmd = new OleDbCommand("SELECT @@IDENTITY", conn))
                {
                    newCustomerId = Convert.ToInt32(idCmd.ExecuteScalar());
                }

                // 3. Создаем карту лояльности для нового покупателя с приветственными бонусами
                string newCardNum = "CARD-" + (10000 + newCustomerId);
                using (OleDbCommand cardCmd = new OleDbCommand("INSERT INTO [КартаЛояльности] ([НомерКарты], [БалансБонусов], [ID_Покупателя]) VALUES (?, ?, ?)", conn))
                {
                    cardCmd.Parameters.Add("?", OleDbType.VarWChar).Value = newCardNum;
                    cardCmd.Parameters.Add("?", OleDbType.Integer).Value = 100; // 100 приветственных бонусов
                    cardCmd.Parameters.Add("?", OleDbType.Integer).Value = newCustomerId;
                    cardCmd.ExecuteNonQuery();
                }

                // 4. Создаем запись в таблице Пользователь
                int newUserId = 1;
                using (OleDbCommand userCmd = new OleDbCommand(
                    "INSERT INTO [Пользователь] ([Логин], [Пароль], [Роль], [ID_Покупателя], [ФИО], [НомерТелефона], [АдресДоставки]) " +
                    "VALUES (?, ?, 'Buyer', ?, ?, ?, ?)", conn))
                {
                    userCmd.Parameters.Add("?", OleDbType.VarWChar).Value = login;
                    userCmd.Parameters.Add("?", OleDbType.VarWChar).Value = password;
                    userCmd.Parameters.Add("?", OleDbType.Integer).Value = newCustomerId;
                    userCmd.Parameters.Add("?", OleDbType.VarWChar).Value = fio;
                    userCmd.Parameters.Add("?", OleDbType.VarWChar).Value = phone;
                    userCmd.Parameters.Add("?", OleDbType.VarWChar).Value = address;
                    userCmd.ExecuteNonQuery();
                }

                using (OleDbCommand idCmd2 = new OleDbCommand("SELECT @@IDENTITY", conn))
                {
                    newUserId = Convert.ToInt32(idCmd2.ExecuteScalar());
                }

                SyncCopies();

                return new User
                {
                    Id = newUserId,
                    Login = login,
                    Role = "Buyer",
                    CustomerId = newCustomerId,
                    FullName = fio,
                    Phone = phone,
                    Address = address
                };
            }
        }

        // ==========================================
        // КАТАЛОГ И КАРТЫ ЛОЯЛЬНОСТИ
        // ==========================================

        public static DataTable GetProducts(string search = "")
        {
            DataTable dt = new DataTable();
            using (OleDbConnection conn = GetConnection())
            {
                string sql = "SELECT [Штрихкод], [Наименование], [Цена], [Вес] FROM [Товар]";
                if (!string.IsNullOrWhiteSpace(search))
                {
                    sql += " WHERE [Наименование] LIKE ? OR [Штрихкод] LIKE ?";
                }
                sql += " ORDER BY [Наименование]";

                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    if (!string.IsNullOrWhiteSpace(search))
                    {
                        cmd.Parameters.Add("?", OleDbType.VarWChar).Value = "%" + search.Trim() + "%";
                        cmd.Parameters.Add("?", OleDbType.VarWChar).Value = "%" + search.Trim() + "%";
                    }
                    using (OleDbDataAdapter da = new OleDbDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        public static bool GetBuyerCard(int customerId, out string cardNumber, out int bonusBalance)
        {
            cardNumber = "";
            bonusBalance = 0;
            if (customerId <= 0) return false;

            using (OleDbConnection conn = GetConnection())
            {
                string sql = "SELECT [НомерКарты], [БалансБонусов] FROM [КартаЛояльности] WHERE [ID_Покупателя] = ?";
                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = customerId;
                    using (OleDbDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            cardNumber = reader["НомерКарты"].ToString();
                            bonusBalance = Convert.ToInt32(reader["БалансБонусов"]);
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public static int GetCustomerBonusBalance(int customerId)
        {
            string card;
            int balance;
            if (GetBuyerCard(customerId, out card, out balance))
            {
                return balance;
            }
            return 0;
        }

        // ==========================================
        // ЗАКАЗЫ (ОФОРМЛЕНИЕ И ПРОСМОТР)
        // ==========================================

        public static bool IsValidDeliveryAddress(string address, out string error)
        {
            error = "";
            if (string.IsNullOrWhiteSpace(address))
            {
                error = "Пожалуйста, укажите адрес доставки (куда курьеру привезти заказ)!";
                return false;
            }

            string trimmed = address.Trim();
            if (trimmed.Length < 10)
            {
                error = "Адрес доставки слишком короткий! Укажите город, улицу и номер дома.\nПример: г. Москва, ул. Ленина, д. 10, кв. 15";
                return false;
            }

            // Проверяем наличие цифр (номер дома/строения обязателен для доставки)
            bool hasDigit = false;
            int letterCount = 0;
            foreach (char c in trimmed)
            {
                if (char.IsDigit(c)) hasDigit = true;
                if (char.IsLetter(c)) letterCount++;
            }

            if (letterCount < 4)
            {
                error = "В адресе доставки должно быть указано название улицы и населенного пункта буквами!";
                return false;
            }

            if (!hasDigit)
            {
                error = "В адресе доставки обязательно должен быть указан номер дома/строения (цифры)!\nПример: ул. Мира, дом 14, кв. 5";
                return false;
            }

            // Проверка на случайный бессмысленный набор символов
            string lower = trimmed.ToLowerInvariant();
            if (lower == "asdfghjk" || lower == "йцукенгшщз" || lower == "1234567890" || lower == "qwertyuiop")
            {
                error = "Указана случайная комбинация клавиш. Введите реальный адрес доставки!";
                return false;
            }

            HashSet<char> uniqueChars = new HashSet<char>();
            foreach (char c in lower) if (char.IsLetterOrDigit(c)) uniqueChars.Add(c);
            if (uniqueChars.Count < 5)
            {
                error = "Адрес не похож на настоящий адрес доставки. Пожалуйста, укажите корректные улицу и дом.";
                return false;
            }

            // Проверка адресных признаков (улица, дом, квартира, проспект и т.д.)
            string[] addressKeywords = new string[] {
                "ул", "улиц", "д.", "дом", "кв", "квартир", "просп", "проспект", "пер.", "переул",
                "проезд", "бульвар", "наб", "набережн", "шоссе", "тракт", "г.", "город", "мкр", "микрорайон",
                "пос", "поселок", "село", "деревн", "корп", "корпус", "стр", "строение"
            };

            bool hasKeyword = false;
            foreach (string kw in addressKeywords)
            {
                if (lower.Contains(kw))
                {
                    hasKeyword = true;
                    break;
                }
            }

            if (!hasKeyword)
            {
                // Если нет ключевого слова, проверяем наличие хотя бы двух слов: название + цифра
                string[] parts = trimmed.Split(new char[] { ' ', ',', '.', ';', '/' }, StringSplitOptions.RemoveEmptyEntries);
                bool hasWordWithLetter = false;
                bool hasWordWithDigit = false;
                foreach (var p in parts)
                {
                    bool wLetter = false, wDigit = false;
                    foreach (char c in p)
                    {
                        if (char.IsLetter(c)) wLetter = true;
                        if (char.IsDigit(c)) wDigit = true;
                    }
                    if (wLetter) hasWordWithLetter = true;
                    if (wDigit) hasWordWithDigit = true;
                }

                if (!hasWordWithLetter || !hasWordWithDigit)
                {
                    error = "Не удалось распознать улицу и номер дома в адресе.\nПожалуйста, укажите адрес в формате: ул. [Название], д. [Номер], кв. [Номер]";
                    return false;
                }
            }

            return true;
        }

        public static bool CreateOrder(User buyer, string address, string paymentType, string cardNumber,
                                       List<CartItem> items, out int newOrderId, out string error)
        {
            return CreateOrder(buyer, address, paymentType, cardNumber, 0, items, out newOrderId, out error);
        }

        public static bool CreateOrder(User buyer, string address, string paymentType, string cardNumber,
                                       int bonusesToSpend, List<CartItem> items, out int newOrderId, out string error)
        {
            newOrderId = 0;
            error = "";

            if (items == null || items.Count == 0)
            {
                error = "Корзина пуста! Добавьте товары перед оформлением.";
                return false;
            }

            if (!IsValidDeliveryAddress(address, out string addrErr))
            {
                error = addrErr;
                return false;
            }

            decimal rawTotal = 0;
            foreach (var item in items)
            {
                rawTotal += item.Total;
            }

            if (bonusesToSpend < 0) bonusesToSpend = 0;
            decimal bonusDiscount = Math.Min((decimal)bonusesToSpend, rawTotal);
            decimal finalPayable = Math.Max(0m, rawTotal - bonusDiscount);

            using (OleDbConnection conn = GetConnection())
            {
                OleDbTransaction trans = conn.BeginTransaction();
                try
                {
                    // 1. Вставляем запись в таблицу Продажа (фактически оплаченная сумма с учетом скидки)
                    string insertSaleSql = "INSERT INTO [Продажа] ([ДатаВремя], [ИтоговаяСумма], [ТипОплаты], [ID_Покупателя], [НомерКарты], [ID_Кассира], [АдресДоставки], [Статус]) " +
                                           "VALUES (?, ?, ?, ?, ?, 1, ?, 'Новый')";

                    using (OleDbCommand cmdSale = new OleDbCommand(insertSaleSql, conn, trans))
                    {
                        cmdSale.Parameters.Add("?", OleDbType.Date).Value = DateTime.Now;
                        cmdSale.Parameters.Add("?", OleDbType.Currency).Value = finalPayable;
                        cmdSale.Parameters.Add("?", OleDbType.VarWChar).Value = paymentType;
                        cmdSale.Parameters.Add("?", OleDbType.Integer).Value = buyer.CustomerId;
                        cmdSale.Parameters.Add("?", OleDbType.VarWChar).Value = !string.IsNullOrEmpty(cardNumber) ? cardNumber : (object)DBNull.Value;
                        cmdSale.Parameters.Add("?", OleDbType.VarWChar).Value = address.Trim();
                        cmdSale.ExecuteNonQuery();
                    }

                    // Получаем id созданной продажи
                    using (OleDbCommand idCmd = new OleDbCommand("SELECT @@IDENTITY", conn, trans))
                    {
                        newOrderId = Convert.ToInt32(idCmd.ExecuteScalar());
                    }

                    // 2. Вставляем позиции в СоставПродажи
                    string insertItemSql = "INSERT INTO [СоставПродажи] ([idПродажи], [Наименование], [Штрихкод], [Количество], [Цена], [Сумма]) " +
                                           "VALUES (?, ?, ?, ?, ?, ?)";

                    foreach (var item in items)
                    {
                        using (OleDbCommand cmdItem = new OleDbCommand(insertItemSql, conn, trans))
                        {
                            cmdItem.Parameters.Add("?", OleDbType.Integer).Value = newOrderId;
                            cmdItem.Parameters.Add("?", OleDbType.VarWChar).Value = item.Name;
                            cmdItem.Parameters.Add("?", OleDbType.VarWChar).Value = item.Barcode;
                            cmdItem.Parameters.Add("?", OleDbType.Integer).Value = item.Quantity;
                            cmdItem.Parameters.Add("?", OleDbType.Currency).Value = item.Price;
                            cmdItem.Parameters.Add("?", OleDbType.Currency).Value = item.Total;
                            cmdItem.ExecuteNonQuery();
                        }
                    }

                    // 3. Обработка карты лояльности: либо списание бонусов, либо начисление
                    if (!string.IsNullOrEmpty(cardNumber))
                    {
                        if (bonusesToSpend > 0)
                        {
                            // Списываем потраченные бонусы
                            int currentBonus = 0;
                            using (OleDbCommand getB = new OleDbCommand("SELECT [БалансБонусов] FROM [КартаЛояльности] WHERE [НомерКарты] = ?", conn, trans))
                            {
                                getB.Parameters.Add("?", OleDbType.VarWChar).Value = cardNumber;
                                object bObj = getB.ExecuteScalar();
                                if (bObj != null && bObj != DBNull.Value) currentBonus = Convert.ToInt32(bObj);
                            }

                            int newBonus = Math.Max(0, currentBonus - bonusesToSpend);
                            using (OleDbCommand cmdSpend = new OleDbCommand("UPDATE [КартаЛояльности] SET [БалансБонусов] = ? WHERE [НомерКарты] = ?", conn, trans))
                            {
                                cmdSpend.Parameters.Add("?", OleDbType.Integer).Value = newBonus;
                                cmdSpend.Parameters.Add("?", OleDbType.VarWChar).Value = cardNumber;
                                cmdSpend.ExecuteNonQuery();
                            }
                        }
                        else
                        {
                            // Начисление 3% бонусов от суммы заказа
                            int addedBonuses = (int)(finalPayable * 0.03m);
                            if (addedBonuses > 0)
                            {
                                string bonusSql = "UPDATE [КартаЛояльности] SET [БалансБонусов] = [БалансБонусов] + ? WHERE [НомерКарты] = ?";
                                using (OleDbCommand cmdBonus = new OleDbCommand(bonusSql, conn, trans))
                                {
                                    cmdBonus.Parameters.Add("?", OleDbType.Integer).Value = addedBonuses;
                                    cmdBonus.Parameters.Add("?", OleDbType.VarWChar).Value = cardNumber;
                                    cmdBonus.ExecuteNonQuery();
                                }
                            }
                        }
                    }

                    trans.Commit();
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    error = "Ошибка при сохранении заказа: " + ex.Message;
                    return false;
                }
            }

            SyncCopies();
            return true;
        }

        // ==========================================
        // УПРАВЛЕНИЕ КАТАЛОГОМ ТОВАРОВ (ДЛЯ АДМИНИСТРАТОРА)
        // ==========================================

        public static bool AddProduct(string barcode, string name, decimal price, double weight, out string error)
        {
            error = "";
            barcode = (barcode ?? "").Trim();
            name = (name ?? "").Trim();

            if (string.IsNullOrEmpty(barcode) || barcode.Length < 3)
            {
                error = "Пожалуйста, укажите корректный штрихкод товара (минимум 3 символа)!";
                return false;
            }

            if (string.IsNullOrEmpty(name) || name.Length < 2)
            {
                error = "Пожалуйста, укажите наименование товара (минимум 2 символа)!";
                return false;
            }

            if (price <= 0)
            {
                error = "Цена товара должна быть строго больше нуля!";
                return false;
            }

            if (weight < 0) weight = 0;

            if (IsBarcodeExists(barcode))
            {
                error = $"Товар со штрихкодом «{barcode}» уже существует в каталоге! Пожалуйста, укажите другой штрихкод или воспользуйтесь кнопкой «Сгенерировать».";
                return false;
            }

            try
            {
                using (OleDbConnection conn = GetConnection())
                {
                    string sql = "INSERT INTO [Товар] ([Штрихкод], [Наименование], [Цена], [Вес]) VALUES (?, ?, ?, ?)";
                    using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                    {
                        cmd.Parameters.Add("?", OleDbType.VarWChar).Value = barcode;
                        cmd.Parameters.Add("?", OleDbType.VarWChar).Value = name;
                        cmd.Parameters.Add("?", OleDbType.Currency).Value = price;
                        cmd.Parameters.Add("?", OleDbType.Double).Value = weight;
                        cmd.ExecuteNonQuery();
                    }
                }
                SyncCopies();
                return true;
            }
            catch (Exception ex)
            {
                error = "Ошибка при добавлении товара в базу данных: " + ex.Message;
                return false;
            }
        }

        public static bool UpdateProduct(string barcode, string name, decimal price, double weight, out string error)
        {
            error = "";
            barcode = (barcode ?? "").Trim();
            name = (name ?? "").Trim();

            if (string.IsNullOrEmpty(name) || name.Length < 2)
            {
                error = "Пожалуйста, укажите наименование товара!";
                return false;
            }

            if (price <= 0)
            {
                error = "Цена товара должна быть строго больше нуля!";
                return false;
            }

            if (weight < 0) weight = 0;

            try
            {
                using (OleDbConnection conn = GetConnection())
                {
                    string sql = "UPDATE [Товар] SET [Наименование] = ?, [Цена] = ?, [Вес] = ? WHERE [Штрихкод] = ?";
                    using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                    {
                        cmd.Parameters.Add("?", OleDbType.VarWChar).Value = name;
                        cmd.Parameters.Add("?", OleDbType.Currency).Value = price;
                        cmd.Parameters.Add("?", OleDbType.Double).Value = weight;
                        cmd.Parameters.Add("?", OleDbType.VarWChar).Value = barcode;
                        int aff = cmd.ExecuteNonQuery();
                        if (aff == 0)
                        {
                            error = "Товар с указанным штрихкодом не найден в базе данных!";
                            return false;
                        }
                    }
                }
                SyncCopies();
                return true;
            }
            catch (Exception ex)
            {
                error = "Ошибка при обновлении товара: " + ex.Message;
                return false;
            }
        }

        public static bool DeleteProduct(string barcode, out string error)
        {
            error = "";
            barcode = (barcode ?? "").Trim();
            if (string.IsNullOrEmpty(barcode))
            {
                error = "Штрихкод не указан!";
                return false;
            }

            try
            {
                using (OleDbConnection conn = GetConnection())
                {
                    // Проверяем, участвовал ли товар в оформленных заказах
                    string checkSql = "SELECT COUNT(*) FROM [СоставПродажи] WHERE [Штрихкод] = ?";
                    using (OleDbCommand checkCmd = new OleDbCommand(checkSql, conn))
                    {
                        checkCmd.Parameters.Add("?", OleDbType.VarWChar).Value = barcode;
                        int usageCount = Convert.ToInt32(checkCmd.ExecuteScalar());
                        if (usageCount > 0)
                        {
                            error = $"Нельзя удалить товар «{barcode}», так как он фигурирует в ранее оформленных заказах ({usageCount} раз)! Вы можете изменить его цену или название.";
                            return false;
                        }
                    }

                    string delSql = "DELETE FROM [Товар] WHERE [Штрихкод] = ?";
                    using (OleDbCommand delCmd = new OleDbCommand(delSql, conn))
                    {
                        delCmd.Parameters.Add("?", OleDbType.VarWChar).Value = barcode;
                        delCmd.ExecuteNonQuery();
                    }
                }
                SyncCopies();
                return true;
            }
            catch (Exception ex)
            {
                error = "Ошибка при удалении товара: " + ex.Message;
                return false;
            }
        }

        public static bool IsBarcodeExists(string barcode)
        {
            if (string.IsNullOrWhiteSpace(barcode)) return false;
            using (OleDbConnection conn = GetConnection())
            {
                string sql = "SELECT COUNT(*) FROM [Товар] WHERE [Штрихкод] = ?";
                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = barcode.Trim();
                    return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
                }
            }
        }

        public static string GenerateUniqueBarcode()
        {
            Random rnd = new Random();
            for (int i = 0; i < 100; i++)
            {
                string candidate = "4600123" + rnd.Next(100000, 999999).ToString();
                if (!IsBarcodeExists(candidate))
                    return candidate;
            }
            return "460" + DateTime.Now.ToString("yyMMddHHmmss");
        }

        public static DataTable GetAllOrdersForAdmin()
        {
            DataTable dt = new DataTable();
            using (OleDbConnection conn = GetConnection())
            {
                // Запрос без точек и спецсимволов в псевдонимах, чтобы Access OLE DB работал без сбоев
                string sql = "SELECT p.[idПродажи] AS [OrderId], " +
                             "       p.[ДатаВремя] AS [OrderDate], " +
                             "       k.[ФИО] AS [CustomerName], " +
                             "       k.[НомерТелефона] AS [CustomerPhone], " +
                             "       p.[АдресДоставки] AS [DeliveryAddress], " +
                             "       p.[ИтоговаяСумма] AS [TotalSum], " +
                             "       p.[ТипОплаты] AS [PaymentType], " +
                             "       p.[Статус] AS [OrderStatus], " +
                             "       p.[НомерКарты] AS [CardNumber] " +
                             "FROM [Продажа] p " +
                             "LEFT JOIN [Покупатель] k ON p.[ID_Покупателя] = k.[ID] " +
                             "ORDER BY p.[idПродажи] DESC";

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, conn))
                {
                    da.Fill(dt);
                }
            }
            return dt;
        }

        public static DataTable GetBuyerOrders(int customerId)
        {
            DataTable dt = new DataTable();
            using (OleDbConnection conn = GetConnection())
            {
                string sql = "SELECT p.[idПродажи] AS [OrderId], " +
                             "       p.[ДатаВремя] AS [OrderDate], " +
                             "       p.[АдресДоставки] AS [DeliveryAddress], " +
                             "       p.[ИтоговаяСумма] AS [TotalSum], " +
                             "       p.[ТипОплаты] AS [PaymentType], " +
                             "       p.[Статус] AS [OrderStatus] " +
                             "FROM [Продажа] p " +
                             "WHERE p.[ID_Покупателя] = ? " +
                             "ORDER BY p.[idПродажи] DESC";

                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = customerId;
                    using (OleDbDataAdapter da = new OleDbDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        public static DataTable GetOrderItems(int orderId)
        {
            DataTable dt = new DataTable();
            using (OleDbConnection conn = GetConnection())
            {
                string sql = "SELECT [idПозиции] AS [ItemId], " +
                             "       [Наименование] AS [ProductName], " +
                             "       [Штрихкод] AS [Barcode], " +
                             "       [Количество] AS [Quantity], " +
                             "       [Цена] AS [Price], " +
                             "       [Сумма] AS [Total] " +
                             "FROM [СоставПродажи] " +
                             "WHERE [idПродажи] = ? " +
                             "ORDER BY [idПозиции]";

                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = orderId;
                    using (OleDbDataAdapter da = new OleDbDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        public static bool UpdateOrderStatus(int orderId, string newStatus)
        {
            try
            {
                using (OleDbConnection conn = GetConnection())
                {
                    string sql = "UPDATE [Продажа] SET [Статус] = ? WHERE [idПродажи] = ?";
                    using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                    {
                        cmd.Parameters.Add("?", OleDbType.VarWChar).Value = newStatus;
                        cmd.Parameters.Add("?", OleDbType.Integer).Value = orderId;
                        cmd.ExecuteNonQuery();
                    }
                }
                SyncCopies();
                return true;
            }
            catch
            {
                return false;
            }
        }

        // ==========================================
        // БАЗА ЗАРЕГИСТРИРОВАННЫХ ПОКУПАТЕЛЕЙ
        // ==========================================

        public static DataTable GetAllBuyersForAdmin()
        {
            DataTable dt = new DataTable();
            using (OleDbConnection conn = GetConnection())
            {
                string sql = "SELECT p.[ID] AS [CustomerId], " +
                             "       p.[ФИО] AS [FullName], " +
                             "       u.[Логин] AS [UserLogin], " +
                             "       p.[НомерТелефона] AS [Phone], " +
                             "       u.[АдресДоставки] AS [DeliveryAddress], " +
                             "       k.[НомерКарты] AS [CardNumber], " +
                             "       k.[БалансБонусов] AS [BonusBalance] " +
                             "FROM ([Покупатель] p " +
                             "LEFT JOIN [Пользователь] u ON p.[ID] = u.[ID_Покупателя]) " +
                             "LEFT JOIN [КартаЛояльности] k ON p.[ID] = k.[ID_Покупателя] " +
                             "ORDER BY p.[ID]";

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, conn))
                {
                    da.Fill(dt);
                }

                // Добавляем столбцы статистики по заказам покупателя
                dt.Columns.Add("OrdersCount", typeof(int));
                dt.Columns.Add("TotalOrdersSum", typeof(decimal));

                // Получаем количество и общую сумму заказов для каждого покупателя
                string statsSql = "SELECT [ID_Покупателя], COUNT([idПродажи]) AS [OrdersCount], SUM([ИтоговаяСумма]) AS [TotalSum] FROM [Продажа] GROUP BY [ID_Покупателя]";
                Dictionary<int, Tuple<int, decimal>> stats = new Dictionary<int, Tuple<int, decimal>>();
                try
                {
                    using (OleDbCommand cmdStats = new OleDbCommand(statsSql, conn))
                    using (OleDbDataReader r = cmdStats.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            if (r["ID_Покупателя"] != DBNull.Value)
                            {
                                int cid = Convert.ToInt32(r["ID_Покупателя"]);
                                int cnt = Convert.ToInt32(r["OrdersCount"]);
                                decimal sum = r["TotalSum"] != DBNull.Value ? Convert.ToDecimal(r["TotalSum"]) : 0m;
                                stats[cid] = Tuple.Create(cnt, sum);
                            }
                        }
                    }
                }
                catch { }

                foreach (DataRow row in dt.Rows)
                {
                    int cid = Convert.ToInt32(row["CustomerId"]);
                    if (stats.ContainsKey(cid))
                    {
                        row["OrdersCount"] = stats[cid].Item1;
                        row["TotalOrdersSum"] = stats[cid].Item2;
                    }
                    else
                    {
                        row["OrdersCount"] = 0;
                        row["TotalOrdersSum"] = 0m;
                    }
                }
            }
            return dt;
        }

        public static DataTable GetAllRegisteredUsersForAuth()
        {
            DataTable dt = new DataTable();
            using (OleDbConnection conn = GetConnection())
            {
                string sql = "SELECT u.[ID] AS [UserId], " +
                             "       u.[Логин] AS [UserLogin], " +
                             "       u.[Пароль] AS [UserPassword], " +
                             "       u.[Роль] AS [Role], " +
                             "       p.[ФИО] AS [FullName], " +
                             "       p.[НомерТелефона] AS [Phone], " +
                             "       k.[НомерКарты] AS [CardNumber], " +
                             "       k.[БалансБонусов] AS [BonusBalance] " +
                             "FROM ([Пользователь] u " +
                             "LEFT JOIN [Покупатель] p ON u.[ID_Покупателя] = p.[ID]) " +
                             "LEFT JOIN [КартаЛояльности] k ON p.[ID] = k.[ID_Покупателя] " +
                             "ORDER BY u.[Роль], u.[ID]";

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, conn))
                {
                    da.Fill(dt);
                }
            }
            return dt;
        }
    }
}
