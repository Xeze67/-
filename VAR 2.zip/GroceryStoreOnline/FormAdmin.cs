using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace GroceryStoreOnline
{
    public class FormAdmin : Form
    {
        private User adminUser;

        // Элементы шапки
        private Label lblAdminTitle;
        private Label lblAdminStats;
        private Button btnRefreshAll;
        private Button btnExit;

        // Вкладки панели управления
        private TabControl tabControlMain;
        private TabPage tabBuyers; // Вкладка 1: Покупатели и их товары (Кто что заказал)
        private TabPage tabOrders; // Вкладка 2: Все онлайн-заказы и доставка
        private TabPage tabProducts; // Вкладка 3: Каталог товаров (Управление и добавление)

        // ==========================================
        // Элементы вкладки 1: "Покупатели и их товары"
        // ==========================================
        private SplitContainer splitBuyersMain;
        private TextBox txtSearchBuyer;
        private Label lblBuyersSummary;
        private DataGridView dgvBuyers;
        private DataTable allBuyersTable;

        // Правая часть вкладки покупателей: карточка, заказы и товары
        private Panel pnlBuyerCard;
        private Label lblBuyerCardTitle;
        private Label lblBuyerCardPhone;
        private Label lblBuyerCardAddress;
        private Label lblBuyerCardStats;

        private SplitContainer splitBuyerRight;
        private Label lblBuyerOrdersHeader;
        private DataGridView dgvBuyerOrders;

        private Label lblBuyerOrderItemsHeader;
        private DataGridView dgvBuyerOrderItems;
        private Label lblBuyerOrderTotalBadge;

        // ==========================================
        // Элементы вкладки 2: "Все онлайн-заказы и доставка"
        // ==========================================
        private SplitContainer splitOrdersMain;
        private TextBox txtSearchOrder;
        private ComboBox cmbFilterStatus;
        private Label lblOrdersSummary;
        private DataGridView dgvOrders;
        private DataTable allOrdersTable;

        // Правая часть вкладки заказов: карточка заказа и состав
        private Panel pnlOrderCard;
        private Label lblOrderDetailTitle;
        private Label lblOrderDetailStatusBadge;
        private Label lblOrderDetailCustomer;
        private Label lblOrderDetailAddress;
        private Label lblOrderDetailPayment;
        private ComboBox cmbChangeStatus;
        private Button btnSaveStatus;

        private Label lblOrderItemsHeader;
        private DataGridView dgvOrderDetails;
        private Label lblOrderTotalBadge;

        // ==========================================
        // Элементы вкладки 3: "Каталог товаров"
        // ==========================================
        private SplitContainer splitProductsMain;
        private TextBox txtSearchProduct;
        private Label lblProductsSummary;
        private DataGridView dgvProducts;
        private DataTable allProductsTable;

        // Правая часть вкладки товаров: добавление/редактирование
        private TextBox txtProductBarcode;
        private Button btnGenBarcode;
        private TextBox txtProductName;
        private NumericUpDown numProductPrice;
        private NumericUpDown numProductWeight;
        private Button btnAddProduct;
        private Button btnEditProduct;
        private Button btnDeleteProduct;
        private Button btnClearProductForm;

        public FormAdmin(User admin)
        {
            this.adminUser = admin;
            InitializeComponent();
            this.Load += FormAdmin_Load;
            this.Resize += (s, e) => { SetSplitterDistances(); };
        }

        private void FormAdmin_Load(object sender, EventArgs e)
        {
            SetSplitterDistances();
            RefreshAllData();
        }

        private void SetSplitterDistances()
        {
            try
            {
                if (splitBuyersMain != null && splitBuyersMain.Width > 500)
                {
                    splitBuyersMain.SplitterDistance = Math.Min(440, splitBuyersMain.Width / 2);
                }
                if (splitOrdersMain != null && splitOrdersMain.Width > 500)
                {
                    splitOrdersMain.SplitterDistance = Math.Min(480, splitOrdersMain.Width / 2);
                }
                if (splitBuyerRight != null && splitBuyerRight.Height > 150)
                {
                    splitBuyerRight.SplitterDistance = splitBuyerRight.Height / 2;
                }
                if (splitProductsMain != null && splitProductsMain.Width > 500)
                {
                    splitProductsMain.SplitterDistance = Math.Max(520, splitProductsMain.Width - 440);
                }
            }
            catch { }
        }

        private void InitializeComponent()
        {
            this.Text = "Панель управления администратора — Онлайн-маркет «Продуктовый»";
            this.Size = new Size(1220, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MinimumSize = new Size(980, 620);
            this.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(204)));
            this.BackColor = Color.FromArgb(244, 246, 249);

            // ==========================================
            // 1. ВЕРХНЯЯ ШАПКА
            // ==========================================
            Panel pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 65,
                BackColor = Color.FromArgb(38, 50, 56)
            };

            lblAdminTitle = new Label
            {
                Text = "Панель управления администратора онлайн-маркета",
                Location = new Point(18, 10),
                AutoSize = true,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 12.5F, FontStyle.Bold)
            };

            lblAdminStats = new Label
            {
                Text = $"Вход: {adminUser.FullName} (логин: {adminUser.Login}) | Загрузка статистики...",
                Location = new Point(18, 38),
                AutoSize = true,
                ForeColor = Color.FromArgb(207, 216, 220),
                Font = new Font("Segoe UI", 9F)
            };

            Panel pnlHeaderRight = new Panel
            {
                Dock = DockStyle.Right,
                Width = 280,
                BackColor = Color.Transparent
            };

            btnRefreshAll = new Button
            {
                Text = "Обновить всё",
                Location = new Point(10, 15),
                Size = new Size(140, 35),
                BackColor = Color.FromArgb(0, 150, 136),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnRefreshAll.FlatAppearance.BorderSize = 0;
            btnRefreshAll.Click += (s, e) => { RefreshAllData(); };

            btnExit = new Button
            {
                Text = "Выход",
                Location = new Point(160, 15),
                Size = new Size(105, 35),
                BackColor = Color.FromArgb(211, 47, 47),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnExit.FlatAppearance.BorderSize = 0;
            btnExit.Click += (s, e) => { this.Close(); };

            pnlHeaderRight.Controls.Add(btnRefreshAll);
            pnlHeaderRight.Controls.Add(btnExit);

            pnlHeader.Controls.Add(pnlHeaderRight);
            pnlHeader.Controls.Add(lblAdminTitle);
            pnlHeader.Controls.Add(lblAdminStats);
            this.Controls.Add(pnlHeader);

            // ==========================================
            // 2. ГЛАВНЫЕ ВКЛАДКИ
            // ==========================================
            tabControlMain = new TabControl
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10.5F, FontStyle.Bold),
                Padding = new Point(18, 8)
            };
            this.Controls.Add(tabControlMain);
            pnlHeader.SendToBack();
            tabControlMain.BringToFront();

            // Вкладка 1: Покупатели и их товары (Кто что заказал) — теперь первая!
            tabBuyers = new TabPage(" Покупатели и их товары (Кто что заказал) ");
            tabBuyers.BackColor = Color.FromArgb(244, 246, 249);
            tabBuyers.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular);

            // Вкладка 2: Все онлайн-заказы и доставка
            tabOrders = new TabPage(" Все онлайн-заказы и доставка ");
            tabOrders.BackColor = Color.FromArgb(244, 246, 249);
            tabOrders.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular);

            // Вкладка 3: Каталог товаров (Управление и добавление)
            tabProducts = new TabPage(" Каталог товаров (Управление и добавление) ");
            tabProducts.BackColor = Color.FromArgb(244, 246, 249);
            tabProducts.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular);

            tabControlMain.TabPages.Add(tabBuyers);
            tabControlMain.TabPages.Add(tabOrders);
            tabControlMain.TabPages.Add(tabProducts);

            BuildBuyersTab();
            BuildOrdersTab();
            BuildProductsTab();
        }

        // =========================================================================
        // ВКЛАДКА 1: ПОКУПАТЕЛИ И ИХ ТОВАРЫ (КТО ЧТО ЗАКАЗАЛ)
        // =========================================================================

        private void BuildBuyersTab()
        {
            splitBuyersMain = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                FixedPanel = FixedPanel.Panel1,
                SplitterDistance = 420,
                Padding = new Padding(6)
            };
            tabBuyers.Controls.Add(splitBuyersMain);

            // ------------------ ЛЕВАЯ ЧАСТЬ: СПИСОК ПОКУПАТЕЛЕЙ ------------------
            Panel pnlBuyersTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 44,
                BackColor = Color.FromArgb(235, 239, 244)
            };

            Label lblBuyersListTitle = new Label
            {
                Text = "Список покупателей:",
                Font = new Font("Segoe UI", 10.5F, FontStyle.Bold),
                Location = new Point(6, 11),
                AutoSize = true
            };

            Panel pnlSearchWrap = new Panel
            {
                Dock = DockStyle.Right,
                Width = 230,
                BackColor = Color.Transparent
            };

            Label lblSearchIcon = new Label
            {
                Text = "Поиск:",
                Location = new Point(4, 12),
                AutoSize = true
            };

            txtSearchBuyer = new TextBox
            {
                Location = new Point(55, 9),
                Width = 168
            };
            txtSearchBuyer.TextChanged += (s, e) => { ApplyBuyerFilter(); };

            pnlSearchWrap.Controls.Add(lblSearchIcon);
            pnlSearchWrap.Controls.Add(txtSearchBuyer);

            pnlBuyersTop.Controls.Add(pnlSearchWrap);
            pnlBuyersTop.Controls.Add(lblBuyersListTitle);

            dgvBuyers = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                ScrollBars = ScrollBars.Both
            };
            dgvBuyers.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgvBuyers.SelectionChanged += DgvBuyers_SelectionChanged;

            Panel pnlBuyersBottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 28,
                BackColor = Color.FromArgb(240, 243, 246)
            };
            lblBuyersSummary = new Label
            {
                Text = "Всего покупателей: 0",
                Location = new Point(6, 6),
                AutoSize = true,
                Font = new Font("Segoe UI", 9F, FontStyle.Italic),
                ForeColor = Color.FromArgb(70, 80, 95)
            };
            pnlBuyersBottom.Controls.Add(lblBuyersSummary);

            splitBuyersMain.Panel1.Controls.Add(dgvBuyers);
            splitBuyersMain.Panel1.Controls.Add(pnlBuyersBottom);
            splitBuyersMain.Panel1.Controls.Add(pnlBuyersTop);
            pnlBuyersTop.SendToBack();
            pnlBuyersBottom.SendToBack();
            dgvBuyers.BringToFront();

            // ------------------ ПРАВАЯ ЧАСТЬ: ДЕТАЛИ, ЗАКАЗЫ И ТОВАРЫ ------------------
            // 1. Верхняя карточка выбранного покупателя
            pnlBuyerCard = new Panel
            {
                Dock = DockStyle.Top,
                Height = 100,
                BackColor = Color.White,
                Padding = new Padding(12, 8, 12, 8)
            };
            pnlBuyerCard.Paint += (s, e) =>
            {
                // Аккуратная синяя полоска слева и граница снизу
                e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(25, 118, 210)), 0, 0, 5, pnlBuyerCard.Height);
                e.Graphics.DrawLine(new Pen(Color.FromArgb(220, 224, 230), 1), 0, pnlBuyerCard.Height - 1, pnlBuyerCard.Width, pnlBuyerCard.Height - 1);
            };

            lblBuyerCardTitle = new Label
            {
                Text = "Выберите покупателя слева для просмотра его заказов и товаров",
                Location = new Point(14, 8),
                AutoSize = true,
                Font = new Font("Segoe UI", 11.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(25, 118, 210)
            };

            lblBuyerCardPhone = new Label
            {
                Text = "Телефон: — | Карта лояльности: — | Баланс бонусов: —",
                Location = new Point(14, 32),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F),
                ForeColor = Color.FromArgb(44, 62, 80)
            };

            lblBuyerCardAddress = new Label
            {
                Text = "Адрес доставки: —",
                Location = new Point(14, 53),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F),
                ForeColor = Color.FromArgb(44, 62, 80)
            };

            lblBuyerCardStats = new Label
            {
                Text = "Оформлено заказов: 0 шт. | Сумма покупок: 0,00 руб.",
                Location = new Point(14, 74),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(46, 125, 50)
            };

            pnlBuyerCard.Controls.Add(lblBuyerCardTitle);
            pnlBuyerCard.Controls.Add(lblBuyerCardPhone);
            pnlBuyerCard.Controls.Add(lblBuyerCardAddress);
            pnlBuyerCard.Controls.Add(lblBuyerCardStats);

            // 2. Сплиттер между заказами покупателя и товарами в выбранном заказе
            splitBuyerRight = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Horizontal,
                SplitterDistance = 210,
                Padding = new Padding(0, 4, 0, 0)
            };
            splitBuyerRight.Resize += (s, e) =>
            {
                try
                {
                    if (splitBuyerRight.Height > 150)
                        splitBuyerRight.SplitterDistance = splitBuyerRight.Height / 2;
                }
                catch { }
            };

            // 2.1 Верх сплиттера: Таблица заказов покупателя
            Panel pnlBuyerOrdersTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 32,
                BackColor = Color.FromArgb(240, 244, 248)
            };
            lblBuyerOrdersHeader = new Label
            {
                Text = "Заказы этого покупателя (нажмите на заказ, чтобы увидеть купленные товары):",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Location = new Point(6, 7),
                AutoSize = true,
                ForeColor = Color.FromArgb(30, 41, 59)
            };
            pnlBuyerOrdersTop.Controls.Add(lblBuyerOrdersHeader);

            dgvBuyerOrders = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                ScrollBars = ScrollBars.Both
            };
            dgvBuyerOrders.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgvBuyerOrders.SelectionChanged += DgvBuyerOrders_SelectionChanged;

            splitBuyerRight.Panel1.Controls.Add(dgvBuyerOrders);
            splitBuyerRight.Panel1.Controls.Add(pnlBuyerOrdersTop);
            pnlBuyerOrdersTop.SendToBack();
            dgvBuyerOrders.BringToFront();

            // 2.2 Низ сплиттера: Товары в выбранном заказе («У кого что есть»)
            Panel pnlBuyerItemsTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 32,
                BackColor = Color.FromArgb(232, 245, 233)
            };
            lblBuyerOrderItemsHeader = new Label
            {
                Text = "Товары в выбранном заказе (Состав покупки):",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Location = new Point(6, 7),
                AutoSize = true,
                ForeColor = Color.FromArgb(46, 125, 50)
            };
            pnlBuyerItemsTop.Controls.Add(lblBuyerOrderItemsHeader);

            Panel pnlBuyerItemsBottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 34,
                BackColor = Color.White
            };
            lblBuyerOrderTotalBadge = new Label
            {
                Text = "ИТОГО В ЗАКАЗЕ: 0,00 руб.",
                Dock = DockStyle.Right,
                Width = 280,
                TextAlign = ContentAlignment.MiddleRight,
                Font = new Font("Segoe UI", 10.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(198, 40, 40),
                Padding = new Padding(0, 0, 10, 0)
            };
            pnlBuyerItemsBottom.Controls.Add(lblBuyerOrderTotalBadge);

            dgvBuyerOrderItems = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                ScrollBars = ScrollBars.Both
            };
            dgvBuyerOrderItems.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);

            splitBuyerRight.Panel2.Controls.Add(dgvBuyerOrderItems);
            splitBuyerRight.Panel2.Controls.Add(pnlBuyerItemsBottom);
            splitBuyerRight.Panel2.Controls.Add(pnlBuyerItemsTop);
            pnlBuyerItemsTop.SendToBack();
            pnlBuyerItemsBottom.SendToBack();
            dgvBuyerOrderItems.BringToFront();

            splitBuyersMain.Panel2.Controls.Add(splitBuyerRight);
            splitBuyersMain.Panel2.Controls.Add(pnlBuyerCard);
            pnlBuyerCard.SendToBack();
            splitBuyerRight.BringToFront();
        }

        // =========================================================================
        // ВКЛАДКА 2: ВСЕ ОНЛАЙН-ЗАКАЗЫ И ДОСТАВКА
        // =========================================================================

        private void BuildOrdersTab()
        {
            splitOrdersMain = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                FixedPanel = FixedPanel.Panel1,
                SplitterDistance = 460,
                Padding = new Padding(6)
            };
            tabOrders.Controls.Add(splitOrdersMain);

            // ------------------ ЛЕВАЯ ЧАСТЬ: СПИСОК ВСЕХ ЗАКАЗОВ ------------------
            Panel pnlOrdersTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 68,
                BackColor = Color.FromArgb(235, 239, 244),
                Padding = new Padding(6)
            };

            Label lblOrdersListTitle = new Label
            {
                Text = "Все онлайн-заказы интернет-магазина:",
                Font = new Font("Segoe UI", 10.5F, FontStyle.Bold),
                Location = new Point(6, 6),
                AutoSize = true
            };

            Label lblSearch = new Label
            {
                Text = "Поиск:",
                Location = new Point(6, 38),
                AutoSize = true
            };

            txtSearchOrder = new TextBox
            {
                Location = new Point(56, 35),
                Width = 145
            };
            txtSearchOrder.TextChanged += (s, e) => { ApplyStatusFilter(); };

            Label lblFilter = new Label
            {
                Text = "Статус:",
                Location = new Point(210, 38),
                AutoSize = true
            };

            cmbFilterStatus = new ComboBox
            {
                Location = new Point(265, 35),
                Width = 135,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbFilterStatus.Items.AddRange(new object[] { "Все заказы", "Доставлен", "Новый", "В сборке", "В доставке", "Отменен" });
            cmbFilterStatus.SelectedIndex = 0;
            cmbFilterStatus.SelectedIndexChanged += (s, e) => { ApplyStatusFilter(); };

            Button btnRefreshOrders = new Button
            {
                Text = "Обновить",
                Location = new Point(408, 33),
                Size = new Size(82, 28),
                BackColor = Color.FromArgb(240, 240, 240),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F),
                Cursor = Cursors.Hand
            };
            btnRefreshOrders.FlatAppearance.BorderColor = Color.LightGray;
            btnRefreshOrders.Click += (s, e) => { LoadOrders(); };

            pnlOrdersTop.Controls.Add(lblOrdersListTitle);
            pnlOrdersTop.Controls.Add(lblSearch);
            pnlOrdersTop.Controls.Add(txtSearchOrder);
            pnlOrdersTop.Controls.Add(lblFilter);
            pnlOrdersTop.Controls.Add(cmbFilterStatus);
            pnlOrdersTop.Controls.Add(btnRefreshOrders);

            dgvOrders = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                ScrollBars = ScrollBars.Both
            };
            dgvOrders.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgvOrders.SelectionChanged += DgvOrders_SelectionChanged;

            Panel pnlOrdersBottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 28,
                BackColor = Color.FromArgb(240, 243, 246)
            };
            lblOrdersSummary = new Label
            {
                Text = "Всего заказов: 0",
                Location = new Point(6, 6),
                AutoSize = true,
                Font = new Font("Segoe UI", 9F, FontStyle.Italic),
                ForeColor = Color.FromArgb(70, 80, 95)
            };
            pnlOrdersBottom.Controls.Add(lblOrdersSummary);

            splitOrdersMain.Panel1.Controls.Add(dgvOrders);
            splitOrdersMain.Panel1.Controls.Add(pnlOrdersBottom);
            splitOrdersMain.Panel1.Controls.Add(pnlOrdersTop);
            pnlOrdersTop.SendToBack();
            pnlOrdersBottom.SendToBack();
            dgvOrders.BringToFront();

            // ------------------ ПРАВАЯ ЧАСТЬ: КАРТОЧКА ЗАКАЗА И ТОВАРЫ ------------------
            // Карточка выбранного заказа
            pnlOrderCard = new Panel
            {
                Dock = DockStyle.Top,
                Height = 140,
                BackColor = Color.White,
                Padding = new Padding(12, 8, 12, 8)
            };
            pnlOrderCard.Paint += (s, e) =>
            {
                e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(0, 150, 136)), 0, 0, 5, pnlOrderCard.Height);
                e.Graphics.DrawLine(new Pen(Color.FromArgb(220, 224, 230), 1), 0, pnlOrderCard.Height - 1, pnlOrderCard.Width, pnlOrderCard.Height - 1);
            };

            lblOrderDetailTitle = new Label
            {
                Text = "Выберите заказ в списке слева",
                Location = new Point(14, 8),
                AutoSize = true,
                Font = new Font("Segoe UI", 12F, FontStyle.Bold),
                ForeColor = Color.FromArgb(38, 50, 56)
            };

            lblOrderDetailStatusBadge = new Label
            {
                Text = "Статус: —",
                Location = new Point(410, 10),
                AutoSize = true,
                Font = new Font("Segoe UI", 10.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(46, 125, 50)
            };

            lblOrderDetailCustomer = new Label
            {
                Text = "Покупатель: — | Телефон: — | Карта лояльности: —",
                Location = new Point(14, 35),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F),
                ForeColor = Color.FromArgb(44, 62, 80)
            };

            lblOrderDetailAddress = new Label
            {
                Text = "Куда везти (Адрес доставки): —",
                Location = new Point(14, 57),
                AutoSize = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = Color.FromArgb(13, 71, 161)
            };

            lblOrderDetailPayment = new Label
            {
                Text = "Способ оплаты: — | Сумма заказа: —",
                Location = new Point(14, 80),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F),
                ForeColor = Color.FromArgb(44, 62, 80)
            };

            // Блок смены статуса
            Panel pnlStatusAction = new Panel
            {
                Location = new Point(14, 103),
                Size = new Size(550, 32),
                BackColor = Color.Transparent
            };

            Label lblStatusChangePrompt = new Label
            {
                Text = "Изменить статус заказа:",
                Location = new Point(0, 6),
                AutoSize = true,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold)
            };

            cmbChangeStatus = new ComboBox
            {
                Location = new Point(160, 3),
                Width = 145,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbChangeStatus.Items.AddRange(new object[] { "Доставлен", "Новый", "В сборке", "В доставке", "Отменен" });
            cmbChangeStatus.SelectedIndex = 0;

            btnSaveStatus = new Button
            {
                Text = "Сохранить статус",
                Location = new Point(315, 2),
                Size = new Size(150, 28),
                BackColor = Color.FromArgb(30, 136, 229),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnSaveStatus.FlatAppearance.BorderSize = 0;
            btnSaveStatus.Click += BtnSaveStatus_Click;

            pnlStatusAction.Controls.Add(lblStatusChangePrompt);
            pnlStatusAction.Controls.Add(cmbChangeStatus);
            pnlStatusAction.Controls.Add(btnSaveStatus);

            pnlOrderCard.Controls.Add(lblOrderDetailTitle);
            pnlOrderCard.Controls.Add(lblOrderDetailStatusBadge);
            pnlOrderCard.Controls.Add(lblOrderDetailCustomer);
            pnlOrderCard.Controls.Add(lblOrderDetailAddress);
            pnlOrderCard.Controls.Add(lblOrderDetailPayment);
            pnlOrderCard.Controls.Add(pnlStatusAction);

            // Заголовок таблицы товаров
            Panel pnlOrderItemsTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 32,
                BackColor = Color.FromArgb(240, 244, 248)
            };
            lblOrderItemsHeader = new Label
            {
                Text = "Товары в выбранном заказе (Содержимое корзины):",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Location = new Point(6, 7),
                AutoSize = true,
                ForeColor = Color.FromArgb(30, 41, 59)
            };
            pnlOrderItemsTop.Controls.Add(lblOrderItemsHeader);

            // Нижняя плашка с итогом
            Panel pnlOrderTotalBottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 36,
                BackColor = Color.White
            };
            lblOrderTotalBadge = new Label
            {
                Text = "ИТОГО К ОПЛАТЕ: 0,00 руб.",
                Dock = DockStyle.Right,
                Width = 280,
                TextAlign = ContentAlignment.MiddleRight,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(198, 40, 40),
                Padding = new Padding(0, 0, 10, 0)
            };
            pnlOrderTotalBottom.Controls.Add(lblOrderTotalBadge);

            dgvOrderDetails = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                ScrollBars = ScrollBars.Both
            };
            dgvOrderDetails.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);

            splitOrdersMain.Panel2.Controls.Add(dgvOrderDetails);
            splitOrdersMain.Panel2.Controls.Add(pnlOrderTotalBottom);
            splitOrdersMain.Panel2.Controls.Add(pnlOrderItemsTop);
            splitOrdersMain.Panel2.Controls.Add(pnlOrderCard);
            pnlOrderCard.SendToBack();
            pnlOrderItemsTop.SendToBack();
            pnlOrderTotalBottom.SendToBack();
            dgvOrderDetails.BringToFront();
        }

        // =========================================================================
        // ВКЛАДКА 3: КАТАЛОГ ТОВАРОВ (УПРАВЛЕНИЕ И ДОБАВЛЕНИЕ)
        // =========================================================================

        private void BuildProductsTab()
        {
            splitProductsMain = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                FixedPanel = FixedPanel.Panel2,
                SplitterDistance = 750,
                Padding = new Padding(6)
            };
            tabProducts.Controls.Add(splitProductsMain);

            // ------------------ ЛЕВАЯ ЧАСТЬ: СПИСОК ТОВАРОВ ------------------
            Panel pnlProductsTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 44,
                BackColor = Color.FromArgb(235, 239, 244)
            };

            Label lblProductsListTitle = new Label
            {
                Text = "Список товаров в магазине:",
                Font = new Font("Segoe UI", 10.5F, FontStyle.Bold),
                Location = new Point(6, 11),
                AutoSize = true
            };

            Panel pnlProductSearchWrap = new Panel
            {
                Dock = DockStyle.Right,
                Width = 320,
                BackColor = Color.Transparent
            };

            Label lblProdSearch = new Label
            {
                Text = "Поиск:",
                Location = new Point(4, 12),
                AutoSize = true
            };

            txtSearchProduct = new TextBox
            {
                Location = new Point(55, 9),
                Width = 250,
                Font = new Font("Segoe UI", 10F)
            };
            txtSearchProduct.TextChanged += (s, e) => { ApplyProductFilter(); };

            pnlProductSearchWrap.Controls.Add(lblProdSearch);
            pnlProductSearchWrap.Controls.Add(txtSearchProduct);

            pnlProductsTop.Controls.Add(lblProductsListTitle);
            pnlProductsTop.Controls.Add(pnlProductSearchWrap);

            // Нижняя панель слева: статистика товаров и кнопка удаления
            Panel pnlProductsBottom = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 46,
                BackColor = Color.FromArgb(235, 239, 244),
                Padding = new Padding(6)
            };

            lblProductsSummary = new Label
            {
                Text = "Загрузка товаров...",
                Location = new Point(10, 14),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                ForeColor = Color.FromArgb(55, 71, 79)
            };

            btnDeleteProduct = new Button
            {
                Text = "Удалить выбранный товар",
                Dock = DockStyle.Right,
                Width = 220,
                BackColor = Color.FromArgb(211, 47, 47),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnDeleteProduct.FlatAppearance.BorderSize = 0;
            btnDeleteProduct.Click += BtnDeleteProduct_Click;

            pnlProductsBottom.Controls.Add(lblProductsSummary);
            pnlProductsBottom.Controls.Add(btnDeleteProduct);

            // Таблица товаров
            dgvProducts = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                AutoGenerateColumns = false,
                BorderStyle = BorderStyle.None,
                GridColor = Color.FromArgb(230, 230, 230)
            };
            dgvProducts.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 250, 252);
            dgvProducts.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(38, 50, 56);
            dgvProducts.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvProducts.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
            dgvProducts.ColumnHeadersHeight = 32;
            dgvProducts.EnableHeadersVisualStyles = false;
            dgvProducts.RowTemplate.Height = 28;

            dgvProducts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Штрихкод",
                HeaderText = "Штрихкод",
                Name = "Barcode",
                Width = 140
            });
            dgvProducts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Наименование",
                HeaderText = "Наименование товара",
                Name = "ProductName",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            });
            var colPrice = new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Цена",
                HeaderText = "Цена (руб.)",
                Name = "Price",
                Width = 100
            };
            colPrice.DefaultCellStyle.Format = "N2";
            colPrice.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvProducts.Columns.Add(colPrice);

            var colWeight = new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Вес",
                HeaderText = "Вес (кг)",
                Name = "Weight",
                Width = 90
            };
            colWeight.DefaultCellStyle.Format = "N3";
            colWeight.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvProducts.Columns.Add(colWeight);

            dgvProducts.SelectionChanged += DgvProducts_SelectionChanged;

            splitProductsMain.Panel1.Controls.Add(dgvProducts);
            splitProductsMain.Panel1.Controls.Add(pnlProductsBottom);
            splitProductsMain.Panel1.Controls.Add(pnlProductsTop);
            pnlProductsTop.SendToBack();
            pnlProductsBottom.SendToBack();
            dgvProducts.BringToFront();

            // ------------------ ПРАВАЯ ЧАСТЬ: ФОРМА ДОБАВЛЕНИЯ / РЕДАКТИРОВАНИЯ ------------------
            Panel pnlProductCard = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(0)
            };

            Panel pnlCardHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                BackColor = Color.FromArgb(238, 242, 246),
                Padding = new Padding(14, 8, 14, 8)
            };

            Label lblFormTitle = new Label
            {
                Text = "Параметры товара",
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                ForeColor = Color.FromArgb(38, 50, 56),
                Location = new Point(12, 8),
                AutoSize = true
            };

            Label lblFormSubtitle = new Label
            {
                Text = "Добавление нового товара или редактирование выбранного",
                Font = new Font("Segoe UI", 8.5F, FontStyle.Regular),
                ForeColor = Color.FromArgb(84, 110, 122),
                Location = new Point(13, 33),
                AutoSize = true
            };

            pnlCardHeader.Controls.Add(lblFormTitle);
            pnlCardHeader.Controls.Add(lblFormSubtitle);

            Panel pnlInputs = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                Padding = new Padding(14)
            };

            int curY = 12;

            // 1. Штрихкод
            Label lblBc = new Label
            {
                Text = "Штрихкод товара (уникальный):",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Location = new Point(14, curY),
                AutoSize = true
            };
            curY += 24;

            txtProductBarcode = new TextBox
            {
                Location = new Point(14, curY),
                Width = 220,
                Font = new Font("Segoe UI", 10F)
            };

            btnGenBarcode = new Button
            {
                Text = "Сгенерировать",
                Location = new Point(242, curY - 1),
                Size = new Size(130, 28),
                BackColor = Color.FromArgb(224, 224, 224),
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 8.5F),
                Cursor = Cursors.Hand
            };
            btnGenBarcode.FlatAppearance.BorderColor = Color.LightGray;
            btnGenBarcode.Click += (s, e) => { txtProductBarcode.Text = DbHelper.GenerateUniqueBarcode(); };

            curY += 38;

            // 2. Наименование
            Label lblName = new Label
            {
                Text = "Наименование товара:",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Location = new Point(14, curY),
                AutoSize = true
            };
            curY += 24;

            txtProductName = new TextBox
            {
                Location = new Point(14, curY),
                Width = 358,
                Font = new Font("Segoe UI", 10F)
            };
            curY += 38;

            // 3. Цена и вес
            Label lblPrice = new Label
            {
                Text = "Цена (руб.):",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Location = new Point(14, curY),
                AutoSize = true
            };

            Label lblWeight = new Label
            {
                Text = "Вес (кг):",
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Location = new Point(198, curY),
                AutoSize = true
            };
            curY += 24;

            numProductPrice = new NumericUpDown
            {
                Location = new Point(14, curY),
                Width = 170,
                DecimalPlaces = 2,
                Minimum = 0.01m,
                Maximum = 100000m,
                Value = 100m,
                Increment = 10m,
                Font = new Font("Segoe UI", 10F)
            };

            numProductWeight = new NumericUpDown
            {
                Location = new Point(198, curY),
                Width = 174,
                DecimalPlaces = 3,
                Minimum = 0m,
                Maximum = 1000m,
                Value = 0.500m,
                Increment = 0.100m,
                Font = new Font("Segoe UI", 10F)
            };
            curY += 45;

            // 4. Кнопки действий
            btnAddProduct = new Button
            {
                Text = "Добавить новый товар в базу",
                Location = new Point(14, curY),
                Size = new Size(358, 42),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnAddProduct.FlatAppearance.BorderSize = 0;
            btnAddProduct.Click += BtnAddProduct_Click;
            curY += 50;

            btnEditProduct = new Button
            {
                Text = "Сохранить изменения (Обновить)",
                Location = new Point(14, curY),
                Size = new Size(358, 36),
                BackColor = Color.FromArgb(2, 136, 209),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnEditProduct.FlatAppearance.BorderSize = 0;
            btnEditProduct.Click += BtnEditProduct_Click;
            curY += 44;

            btnClearProductForm = new Button
            {
                Text = "Очистить форму (Создать новый штрихкод)",
                Location = new Point(14, curY),
                Size = new Size(358, 32),
                BackColor = Color.FromArgb(120, 144, 156),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F),
                Cursor = Cursors.Hand
            };
            btnClearProductForm.FlatAppearance.BorderSize = 0;
            btnClearProductForm.Click += (s, e) => { ClearProductForm(); };
            curY += 44;

            // 5. Блок подсказки
            Panel pnlHint = new Panel
            {
                Location = new Point(14, curY),
                Size = new Size(358, 140),
                BackColor = Color.FromArgb(241, 248, 233),
                BorderStyle = BorderStyle.FixedSingle,
                Padding = new Padding(10)
            };

            Label lblHint = new Label
            {
                Text = "Инструкция администратора:\n" +
                       "• Добавление: введите название, цену и вес, нажмите «Добавить новый товар в базу».\n" +
                       "• Редактирование: выберите товар из списка слева, измените значения и нажмите «Сохранить изменения».\n" +
                       "• Удаление: выберите товар слева и нажмите красную кнопку снизу.\n" +
                       "• Все новые товары сразу становятся доступны покупателям в каталоге онлайн-маркета.",
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 8.5F),
                ForeColor = Color.FromArgb(46, 125, 50)
            };
            pnlHint.Controls.Add(lblHint);

            pnlInputs.Controls.Add(lblBc);
            pnlInputs.Controls.Add(txtProductBarcode);
            pnlInputs.Controls.Add(btnGenBarcode);
            pnlInputs.Controls.Add(lblName);
            pnlInputs.Controls.Add(txtProductName);
            pnlInputs.Controls.Add(lblPrice);
            pnlInputs.Controls.Add(numProductPrice);
            pnlInputs.Controls.Add(lblWeight);
            pnlInputs.Controls.Add(numProductWeight);
            pnlInputs.Controls.Add(btnAddProduct);
            pnlInputs.Controls.Add(btnEditProduct);
            pnlInputs.Controls.Add(btnClearProductForm);
            pnlInputs.Controls.Add(pnlHint);

            pnlProductCard.Controls.Add(pnlInputs);
            pnlProductCard.Controls.Add(pnlCardHeader);
            pnlCardHeader.SendToBack();
            pnlInputs.BringToFront();

            splitProductsMain.Panel2.Controls.Add(pnlProductCard);

            ClearProductForm();
        }

        // =========================================================================
        // ЗАГРУЗКА И СИНХРОНИЗАЦИЯ ДАННЫХ
        // =========================================================================

        private void RefreshAllData()
        {
            LoadBuyers();
            LoadOrders();
            LoadProducts();
            UpdateHeaderStatistics();
        }

        private void UpdateHeaderStatistics()
        {
            try
            {
                int buyersCount = allBuyersTable != null ? allBuyersTable.Rows.Count : 0;
                int ordersCount = allOrdersTable != null ? allOrdersTable.Rows.Count : 0;
                int productsCount = allProductsTable != null ? allProductsTable.Rows.Count : 0;

                int activeOrders = 0;
                int completedOrders = 0;
                decimal totalRevenue = 0;

                if (allOrdersTable != null)
                {
                    foreach (DataRow r in allOrdersTable.Rows)
                    {
                        string status = r["OrderStatus"] != DBNull.Value ? r["OrderStatus"].ToString() : "";
                        decimal sum = r["TotalSum"] != DBNull.Value ? Convert.ToDecimal(r["TotalSum"]) : 0m;

                        if (status == "Доставлен")
                        {
                            completedOrders++;
                            totalRevenue += sum;
                        }
                        else if (status == "Новый" || status == "В сборке" || status == "В доставке")
                        {
                            activeOrders++;
                        }
                    }
                }

                string activeInfo = activeOrders > 0
                    ? $"Активных заказов: {activeOrders} (требуют доставки!)"
                    : "Активных заказов: 0 (все доставлены)";

                lblAdminStats.Text = $"Вход: {adminUser.FullName} (логин: {adminUser.Login}) | Товаров в каталоге: {productsCount} | Клиентов: {buyersCount} | Всего заказов: {ordersCount} | {activeInfo} | Выручка: {totalRevenue:N2} руб.";
            }
            catch { }
        }

        // =========================================================================
        // ЛОГИКА ВКЛАДКИ 1: ПОКУПАТЕЛИ И ИХ ТОВАРЫ
        // =========================================================================

        private void LoadBuyers()
        {
            try
            {
                allBuyersTable = DbHelper.GetAllBuyersForAdmin();
                ApplyBuyerFilter();

                if (dgvBuyers.Columns["CustomerId"] != null)
                {
                    dgvBuyers.Columns["CustomerId"].HeaderText = "ID";
                    dgvBuyers.Columns["CustomerId"].Width = 45;
                    dgvBuyers.Columns["CustomerId"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }
                if (dgvBuyers.Columns["FullName"] != null)
                {
                    dgvBuyers.Columns["FullName"].HeaderText = "ФИО покупателя";
                    dgvBuyers.Columns["FullName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    dgvBuyers.Columns["FullName"].DefaultCellStyle.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
                }
                if (dgvBuyers.Columns["UserLogin"] != null)
                {
                    dgvBuyers.Columns["UserLogin"].HeaderText = "Логин";
                    dgvBuyers.Columns["UserLogin"].Width = 85;
                    dgvBuyers.Columns["UserLogin"].DefaultCellStyle.ForeColor = Color.FromArgb(0, 102, 204);
                }
                if (dgvBuyers.Columns["OrdersCount"] != null)
                {
                    dgvBuyers.Columns["OrdersCount"].HeaderText = "Заказов";
                    dgvBuyers.Columns["OrdersCount"].Width = 65;
                    dgvBuyers.Columns["OrdersCount"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }
                if (dgvBuyers.Columns["TotalOrdersSum"] != null)
                {
                    dgvBuyers.Columns["TotalOrdersSum"].HeaderText = "Сумма (руб.)";
                    dgvBuyers.Columns["TotalOrdersSum"].Width = 100;
                    dgvBuyers.Columns["TotalOrdersSum"].DefaultCellStyle.Format = "N2";
                    dgvBuyers.Columns["TotalOrdersSum"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
                if (dgvBuyers.Columns["BonusBalance"] != null)
                {
                    dgvBuyers.Columns["BonusBalance"].HeaderText = "Бонусы";
                    dgvBuyers.Columns["BonusBalance"].Width = 75;
                    dgvBuyers.Columns["BonusBalance"].DefaultCellStyle.Format = "N0";
                    dgvBuyers.Columns["BonusBalance"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
                if (dgvBuyers.Columns["Phone"] != null) dgvBuyers.Columns["Phone"].Visible = false;
                if (dgvBuyers.Columns["DeliveryAddress"] != null) dgvBuyers.Columns["DeliveryAddress"].Visible = false;
                if (dgvBuyers.Columns["CardNumber"] != null) dgvBuyers.Columns["CardNumber"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке покупателей:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ApplyBuyerFilter()
        {
            if (allBuyersTable == null) return;

            string search = txtSearchBuyer != null ? txtSearchBuyer.Text.Trim() : "";
            DataView dv = new DataView(allBuyersTable);

            if (!string.IsNullOrEmpty(search))
            {
                dv.RowFilter = $"[FullName] LIKE '%{search}%' OR [UserLogin] LIKE '%{search}%' OR [Phone] LIKE '%{search}%' OR [CardNumber] LIKE '%{search}%' OR [DeliveryAddress] LIKE '%{search}%'";
            }

            dgvBuyers.DataSource = dv;
            lblBuyersSummary.Text = $"Всего покупателей: {allBuyersTable.Rows.Count} | Отображается: {dv.Count}";

            if (dgvBuyers.Rows.Count > 0)
            {
                dgvBuyers.Rows[0].Selected = true;
                LoadSelectedBuyerDetails();
            }
            else
            {
                ClearBuyerCard();
            }
        }

        private void DgvBuyers_SelectionChanged(object sender, EventArgs e)
        {
            LoadSelectedBuyerDetails();
        }

        private void ClearBuyerCard()
        {
            lblBuyerCardTitle.Text = "Покупатель не выбран";
            lblBuyerCardPhone.Text = "Телефон: — | Карта лояльности: — | Баланс бонусов: —";
            lblBuyerCardAddress.Text = "Адрес доставки: —";
            lblBuyerCardStats.Text = "Оформлено заказов: 0 шт. | Сумма покупок: 0,00 руб.";
            dgvBuyerOrders.DataSource = null;
            dgvBuyerOrderItems.DataSource = null;
            lblBuyerOrderTotalBadge.Text = "ИТОГО В ЗАКАЗЕ: 0,00 руб.";
        }

        private void LoadSelectedBuyerDetails()
        {
            if (dgvBuyers.CurrentRow == null)
            {
                ClearBuyerCard();
                return;
            }

            try
            {
                var row = dgvBuyers.CurrentRow;
                int custId = Convert.ToInt32(row.Cells["CustomerId"].Value);
                string fullName = row.Cells["FullName"].Value != null ? row.Cells["FullName"].Value.ToString() : "";
                string login = row.Cells["UserLogin"].Value != null ? row.Cells["UserLogin"].Value.ToString() : "";
                string phone = row.Cells["Phone"].Value != null ? row.Cells["Phone"].Value.ToString() : "";
                string addr = row.Cells["DeliveryAddress"].Value != null ? row.Cells["DeliveryAddress"].Value.ToString() : "";
                string card = row.Cells["CardNumber"].Value != null ? row.Cells["CardNumber"].Value.ToString() : "отсутствует";
                string bonuses = row.Cells["BonusBalance"].Value != null ? row.Cells["BonusBalance"].Value.ToString() : "0";
                int ordersCount = row.Cells["OrdersCount"].Value != null ? Convert.ToInt32(row.Cells["OrdersCount"].Value) : 0;
                decimal ordersSum = row.Cells["TotalOrdersSum"].Value != null ? Convert.ToDecimal(row.Cells["TotalOrdersSum"].Value) : 0m;

                lblBuyerCardTitle.Text = $"Покупатель: {fullName} (Логин: {login})";
                lblBuyerCardPhone.Text = $"Телефон: {phone} | Карта лояльности: {card} (Бонусный баланс: {bonuses} баллов)";
                lblBuyerCardAddress.Text = $"Адрес доставки по умолчанию: {addr}";
                lblBuyerCardStats.Text = $"Оформлено заказов: {ordersCount} шт. | Общая сумма покупок: {ordersSum:N2} руб.";

                // Загружаем заказы покупателя
                DataTable dtOrders = DbHelper.GetBuyerOrders(custId);
                dgvBuyerOrders.DataSource = dtOrders;

                if (dgvBuyerOrders.Columns["OrderId"] != null) { dgvBuyerOrders.Columns["OrderId"].HeaderText = "№ заказа"; dgvBuyerOrders.Columns["OrderId"].Width = 75; dgvBuyerOrders.Columns["OrderId"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; }
                if (dgvBuyerOrders.Columns["OrderDate"] != null) { dgvBuyerOrders.Columns["OrderDate"].HeaderText = "Дата и время"; dgvBuyerOrders.Columns["OrderDate"].Width = 125; }
                if (dgvBuyerOrders.Columns["DeliveryAddress"] != null) { dgvBuyerOrders.Columns["DeliveryAddress"].HeaderText = "Куда везти (Адрес доставки)"; dgvBuyerOrders.Columns["DeliveryAddress"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill; }
                if (dgvBuyerOrders.Columns["TotalSum"] != null)
                {
                    dgvBuyerOrders.Columns["TotalSum"].HeaderText = "Сумма (руб.)";
                    dgvBuyerOrders.Columns["TotalSum"].Width = 100;
                    dgvBuyerOrders.Columns["TotalSum"].DefaultCellStyle.Format = "N2";
                    dgvBuyerOrders.Columns["TotalSum"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
                if (dgvBuyerOrders.Columns["PaymentType"] != null) { dgvBuyerOrders.Columns["PaymentType"].HeaderText = "Оплата"; dgvBuyerOrders.Columns["PaymentType"].Width = 140; }
                if (dgvBuyerOrders.Columns["OrderStatus"] != null)
                {
                    dgvBuyerOrders.Columns["OrderStatus"].HeaderText = "Статус";
                    dgvBuyerOrders.Columns["OrderStatus"].Width = 100;
                    dgvBuyerOrders.Columns["OrderStatus"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }

                if (dtOrders.Rows.Count > 0)
                {
                    lblBuyerOrdersHeader.Text = $"Заказы покупателя ({dtOrders.Rows.Count} шт.) — выберите заказ, чтобы увидеть купленные товары:";
                    dgvBuyerOrders.Rows[0].Selected = true;
                    LoadSelectedBuyerOrderItems();
                }
                else
                {
                    lblBuyerOrdersHeader.Text = "У данного покупателя пока нет оформленных заказов.";
                    dgvBuyerOrderItems.DataSource = null;
                    lblBuyerOrderItemsHeader.Text = "Товары отсутствуют (заказов нет).";
                    lblBuyerOrderTotalBadge.Text = "ИТОГО В ЗАКАЗЕ: 0,00 руб.";
                }
            }
            catch { }
        }

        private void DgvBuyerOrders_SelectionChanged(object sender, EventArgs e)
        {
            LoadSelectedBuyerOrderItems();
        }

        private void LoadSelectedBuyerOrderItems()
        {
            if (dgvBuyerOrders.CurrentRow == null || dgvBuyerOrders.CurrentRow.Cells["OrderId"].Value == null || dgvBuyerOrders.CurrentRow.Cells["OrderId"].Value == DBNull.Value)
            {
                dgvBuyerOrderItems.DataSource = null;
                lblBuyerOrderItemsHeader.Text = "Выберите заказ выше для просмотра купленных товаров.";
                lblBuyerOrderTotalBadge.Text = "ИТОГО В ЗАКАЗЕ: 0,00 руб.";
                return;
            }

            try
            {
                int orderId = Convert.ToInt32(dgvBuyerOrders.CurrentRow.Cells["OrderId"].Value);
                string orderDate = dgvBuyerOrders.CurrentRow.Cells["OrderDate"].Value != null ? dgvBuyerOrders.CurrentRow.Cells["OrderDate"].Value.ToString() : "";
                string orderStatus = dgvBuyerOrders.CurrentRow.Cells["OrderStatus"].Value != null ? dgvBuyerOrders.CurrentRow.Cells["OrderStatus"].Value.ToString() : "";

                lblBuyerOrderItemsHeader.Text = $"Товары в заказе №{orderId} от {orderDate} (Статус: «{orderStatus}»):";

                DataTable dtItems = DbHelper.GetOrderItems(orderId);
                dgvBuyerOrderItems.DataSource = dtItems;

                if (dgvBuyerOrderItems.Columns["ItemId"] != null) { dgvBuyerOrderItems.Columns["ItemId"].HeaderText = "№"; dgvBuyerOrderItems.Columns["ItemId"].Width = 45; dgvBuyerOrderItems.Columns["ItemId"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; }
                if (dgvBuyerOrderItems.Columns["ProductName"] != null) { dgvBuyerOrderItems.Columns["ProductName"].HeaderText = "Наименование товара"; dgvBuyerOrderItems.Columns["ProductName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill; dgvBuyerOrderItems.Columns["ProductName"].DefaultCellStyle.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold); }
                if (dgvBuyerOrderItems.Columns["Barcode"] != null) { dgvBuyerOrderItems.Columns["Barcode"].HeaderText = "Штрихкод"; dgvBuyerOrderItems.Columns["Barcode"].Width = 120; }
                if (dgvBuyerOrderItems.Columns["Quantity"] != null) { dgvBuyerOrderItems.Columns["Quantity"].HeaderText = "Кол-во"; dgvBuyerOrderItems.Columns["Quantity"].Width = 70; dgvBuyerOrderItems.Columns["Quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; }
                if (dgvBuyerOrderItems.Columns["Price"] != null)
                {
                    dgvBuyerOrderItems.Columns["Price"].HeaderText = "Цена за шт.";
                    dgvBuyerOrderItems.Columns["Price"].Width = 95;
                    dgvBuyerOrderItems.Columns["Price"].DefaultCellStyle.Format = "N2";
                    dgvBuyerOrderItems.Columns["Price"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
                if (dgvBuyerOrderItems.Columns["Total"] != null)
                {
                    dgvBuyerOrderItems.Columns["Total"].HeaderText = "Стоимость";
                    dgvBuyerOrderItems.Columns["Total"].Width = 105;
                    dgvBuyerOrderItems.Columns["Total"].DefaultCellStyle.Format = "N2";
                    dgvBuyerOrderItems.Columns["Total"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }

                decimal sum = 0;
                int totalPieces = 0;
                foreach (DataRow r in dtItems.Rows)
                {
                    if (r["Total"] != DBNull.Value) sum += Convert.ToDecimal(r["Total"]);
                    if (r["Quantity"] != DBNull.Value) totalPieces += Convert.ToInt32(r["Quantity"]);
                }

                lblBuyerOrderTotalBadge.Text = $"ИТОГО: {sum:N2} руб. ({dtItems.Rows.Count} поз., {totalPieces} шт.)";
            }
            catch { }
        }

        // =========================================================================
        // ЛОГИКА ВКЛАДКИ 2: ВСЕ ОНЛАЙН-ЗАКАЗЫ И ДОСТАВКА
        // =========================================================================

        private void LoadOrders()
        {
            try
            {
                allOrdersTable = DbHelper.GetAllOrdersForAdmin();
                ApplyStatusFilter();

                if (dgvOrders.Columns["OrderId"] != null)
                {
                    dgvOrders.Columns["OrderId"].HeaderText = "№ заказа";
                    dgvOrders.Columns["OrderId"].Width = 65;
                    dgvOrders.Columns["OrderId"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }
                if (dgvOrders.Columns["OrderDate"] != null)
                {
                    dgvOrders.Columns["OrderDate"].HeaderText = "Дата";
                    dgvOrders.Columns["OrderDate"].Width = 115;
                }
                if (dgvOrders.Columns["CustomerName"] != null)
                {
                    dgvOrders.Columns["CustomerName"].HeaderText = "Кому (Покупатель)";
                    dgvOrders.Columns["CustomerName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    dgvOrders.Columns["CustomerName"].DefaultCellStyle.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
                }
                if (dgvOrders.Columns["TotalSum"] != null)
                {
                    dgvOrders.Columns["TotalSum"].HeaderText = "Сумма";
                    dgvOrders.Columns["TotalSum"].Width = 90;
                    dgvOrders.Columns["TotalSum"].DefaultCellStyle.Format = "N2";
                    dgvOrders.Columns["TotalSum"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
                if (dgvOrders.Columns["OrderStatus"] != null)
                {
                    dgvOrders.Columns["OrderStatus"].HeaderText = "Статус";
                    dgvOrders.Columns["OrderStatus"].Width = 100;
                    dgvOrders.Columns["OrderStatus"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }
                if (dgvOrders.Columns["CustomerPhone"] != null) dgvOrders.Columns["CustomerPhone"].Visible = false;
                if (dgvOrders.Columns["DeliveryAddress"] != null) dgvOrders.Columns["DeliveryAddress"].Visible = false;
                if (dgvOrders.Columns["PaymentType"] != null) dgvOrders.Columns["PaymentType"].Visible = false;
                if (dgvOrders.Columns["CardNumber"] != null) dgvOrders.Columns["CardNumber"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке заказов:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ApplyStatusFilter()
        {
            if (allOrdersTable == null) return;

            string statusFilter = cmbFilterStatus.SelectedItem != null ? cmbFilterStatus.SelectedItem.ToString() : "Все заказы";
            string search = txtSearchOrder != null ? txtSearchOrder.Text.Trim() : "";

            string filterExpression = "";
            if (statusFilter != "Все заказы")
            {
                filterExpression = $"[OrderStatus] = '{statusFilter}'";
            }

            if (!string.IsNullOrEmpty(search))
            {
                string searchCond = $"([CustomerName] LIKE '%{search}%' OR [DeliveryAddress] LIKE '%{search}%' OR [CustomerPhone] LIKE '%{search}%')";
                if (!string.IsNullOrEmpty(filterExpression))
                    filterExpression += " AND " + searchCond;
                else
                    filterExpression = searchCond;
            }

            DataView dv = new DataView(allOrdersTable);
            if (!string.IsNullOrEmpty(filterExpression))
            {
                dv.RowFilter = filterExpression;
            }
            dgvOrders.DataSource = dv;
            lblOrdersSummary.Text = $"Всего заказов: {allOrdersTable.Rows.Count} | Отображается: {dv.Count}";

            if (dgvOrders.Rows.Count > 0)
            {
                dgvOrders.Rows[0].Selected = true;
                LoadSelectedOrderDetails();
            }
            else
            {
                ClearOrderCard();
            }
        }

        private void DgvOrders_SelectionChanged(object sender, EventArgs e)
        {
            LoadSelectedOrderDetails();
        }

        private void ClearOrderCard()
        {
            lblOrderDetailTitle.Text = "Заказ не выбран";
            lblOrderDetailStatusBadge.Text = "Статус: —";
            lblOrderDetailCustomer.Text = "Покупатель: — | Телефон: — | Карта: —";
            lblOrderDetailAddress.Text = "Куда везти (Адрес доставки): —";
            lblOrderDetailPayment.Text = "Способ оплаты: — | Сумма заказа: —";
            dgvOrderDetails.DataSource = null;
            lblOrderTotalBadge.Text = "ИТОГО К ОПЛАТЕ: 0,00 руб.";
        }

        private void LoadSelectedOrderDetails()
        {
            if (dgvOrders.CurrentRow == null || dgvOrders.CurrentRow.Cells["OrderId"].Value == null || dgvOrders.CurrentRow.Cells["OrderId"].Value == DBNull.Value)
            {
                ClearOrderCard();
                return;
            }

            try
            {
                var row = dgvOrders.CurrentRow;
                int orderId = Convert.ToInt32(row.Cells["OrderId"].Value);
                string date = row.Cells["OrderDate"].Value != null ? row.Cells["OrderDate"].Value.ToString() : "";
                string customer = row.Cells["CustomerName"].Value != null ? row.Cells["CustomerName"].Value.ToString() : "";
                string phone = row.Cells["CustomerPhone"].Value != null ? row.Cells["CustomerPhone"].Value.ToString() : "";
                string address = row.Cells["DeliveryAddress"].Value != null ? row.Cells["DeliveryAddress"].Value.ToString() : "";
                string status = row.Cells["OrderStatus"].Value != null ? row.Cells["OrderStatus"].Value.ToString() : "Доставлен";
                decimal total = row.Cells["TotalSum"].Value != null ? Convert.ToDecimal(row.Cells["TotalSum"].Value) : 0m;
                string payment = row.Cells["PaymentType"].Value != null ? row.Cells["PaymentType"].Value.ToString() : "";
                string card = row.Cells["CardNumber"].Value != null ? row.Cells["CardNumber"].Value.ToString() : "отсутствует";

                lblOrderDetailTitle.Text = $"Заказ №{orderId} от {date}";
                lblOrderDetailStatusBadge.Text = $"Статус: «{status}»";
                lblOrderDetailStatusBadge.ForeColor = (status == "Доставлен") ? Color.FromArgb(46, 125, 50) : Color.FromArgb(230, 81, 0);

                lblOrderDetailCustomer.Text = $"Покупатель: {customer} | Телефон: {phone} | Карта лояльности: {card}";
                lblOrderDetailAddress.Text = $"Куда везти (Адрес доставки): {address}";
                lblOrderDetailPayment.Text = $"Способ оплаты: {payment} | Сумма к оплате: {total:N2} руб.";

                // Устанавливаем текущий статус в комбобоксе
                if (cmbChangeStatus.Items.Contains(status))
                    cmbChangeStatus.SelectedItem = status;

                // Загружаем товары в заказе
                lblOrderItemsHeader.Text = $"Товары в заказе №{orderId} (что везти клиенту):";
                DataTable dtDetails = DbHelper.GetOrderItems(orderId);
                dgvOrderDetails.DataSource = dtDetails;

                if (dgvOrderDetails.Columns["ItemId"] != null) { dgvOrderDetails.Columns["ItemId"].HeaderText = "№"; dgvOrderDetails.Columns["ItemId"].Width = 45; dgvOrderDetails.Columns["ItemId"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; }
                if (dgvOrderDetails.Columns["ProductName"] != null) { dgvOrderDetails.Columns["ProductName"].HeaderText = "Наименование товара"; dgvOrderDetails.Columns["ProductName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill; dgvOrderDetails.Columns["ProductName"].DefaultCellStyle.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold); }
                if (dgvOrderDetails.Columns["Barcode"] != null) { dgvOrderDetails.Columns["Barcode"].HeaderText = "Штрихкод"; dgvOrderDetails.Columns["Barcode"].Width = 120; }
                if (dgvOrderDetails.Columns["Quantity"] != null) { dgvOrderDetails.Columns["Quantity"].HeaderText = "Кол-во"; dgvOrderDetails.Columns["Quantity"].Width = 70; dgvOrderDetails.Columns["Quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; }
                if (dgvOrderDetails.Columns["Price"] != null)
                {
                    dgvOrderDetails.Columns["Price"].HeaderText = "Цена за шт.";
                    dgvOrderDetails.Columns["Price"].Width = 95;
                    dgvOrderDetails.Columns["Price"].DefaultCellStyle.Format = "N2";
                    dgvOrderDetails.Columns["Price"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
                if (dgvOrderDetails.Columns["Total"] != null)
                {
                    dgvOrderDetails.Columns["Total"].HeaderText = "Стоимость";
                    dgvOrderDetails.Columns["Total"].Width = 105;
                    dgvOrderDetails.Columns["Total"].DefaultCellStyle.Format = "N2";
                    dgvOrderDetails.Columns["Total"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }

                int totalPieces = 0;
                foreach (DataRow r in dtDetails.Rows)
                {
                    if (r["Quantity"] != DBNull.Value) totalPieces += Convert.ToInt32(r["Quantity"]);
                }

                lblOrderTotalBadge.Text = $"ИТОГО: {total:N2} руб. ({dtDetails.Rows.Count} поз., {totalPieces} шт.)";
            }
            catch { }
        }

        private void BtnSaveStatus_Click(object sender, EventArgs e)
        {
            if (dgvOrders.CurrentRow == null || dgvOrders.CurrentRow.Cells["OrderId"].Value == null || dgvOrders.CurrentRow.Cells["OrderId"].Value == DBNull.Value)
            {
                MessageBox.Show("Пожалуйста, выберите заказ из списка слева!", "Заказ не выбран", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            int orderId = Convert.ToInt32(dgvOrders.CurrentRow.Cells["OrderId"].Value);
            string newStatus = cmbChangeStatus.SelectedItem != null ? cmbChangeStatus.SelectedItem.ToString() : "Доставлен";

            if (DbHelper.UpdateOrderStatus(orderId, newStatus))
            {
                MessageBox.Show($"Статус заказа №{orderId} успешно изменен на «{newStatus}»!", "Статус сохранен", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshAllData();
            }
            else
            {
                MessageBox.Show("Ошибка при сохранении статуса заказа в базе данных.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // =========================================================================
        // ЛОГИКА ВКЛАДКИ 3: КАТАЛОГ ТОВАРОВ
        // =========================================================================

        private void LoadProducts()
        {
            try
            {
                allProductsTable = DbHelper.GetProducts();
                dgvProducts.DataSource = allProductsTable;
                ApplyProductFilter();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при загрузке каталога товаров: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ApplyProductFilter()
        {
            if (allProductsTable == null) return;

            string search = (txtSearchProduct != null ? txtSearchProduct.Text : "").Trim().Replace("'", "''");
            if (!string.IsNullOrEmpty(search))
            {
                allProductsTable.DefaultView.RowFilter = string.Format("[Наименование] LIKE '%{0}%' OR [Штрихкод] LIKE '%{0}%'", search);
            }
            else
            {
                allProductsTable.DefaultView.RowFilter = "";
            }

            int visibleCount = allProductsTable.DefaultView.Count;
            int totalCount = allProductsTable.Rows.Count;

            if (lblProductsSummary != null)
            {
                lblProductsSummary.Text = string.IsNullOrEmpty(search)
                    ? $"Всего товаров в каталоге: {totalCount} шт."
                    : $"Найдено товаров: {visibleCount} из {totalCount} шт.";
            }
        }

        private void DgvProducts_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvProducts.CurrentRow == null || dgvProducts.CurrentRow.DataBoundItem == null)
            {
                return;
            }

            try
            {
                DataRowView rowView = dgvProducts.CurrentRow.DataBoundItem as DataRowView;
                if (rowView != null)
                {
                    DataRow r = rowView.Row;
                    txtProductBarcode.Text = r["Штрихкод"] != DBNull.Value ? r["Штрихкод"].ToString() : "";
                    txtProductName.Text = r["Наименование"] != DBNull.Value ? r["Наименование"].ToString() : "";

                    if (r["Цена"] != DBNull.Value)
                    {
                        decimal p = Convert.ToDecimal(r["Цена"]);
                        if (p >= numProductPrice.Minimum && p <= numProductPrice.Maximum)
                            numProductPrice.Value = p;
                    }

                    if (r["Вес"] != DBNull.Value)
                    {
                        decimal w = Convert.ToDecimal(r["Вес"]);
                        if (w >= numProductWeight.Minimum && w <= numProductWeight.Maximum)
                            numProductWeight.Value = w;
                    }
                }
            }
            catch { }
        }

        private void ClearProductForm()
        {
            txtProductBarcode.Text = DbHelper.GenerateUniqueBarcode();
            txtProductName.Text = "";
            numProductPrice.Value = 100m;
            numProductWeight.Value = 0.500m;
            txtProductName.Focus();
        }

        private void BtnAddProduct_Click(object sender, EventArgs e)
        {
            string barcode = txtProductBarcode.Text.Trim();
            string name = txtProductName.Text.Trim();
            decimal price = numProductPrice.Value;
            double weight = (double)numProductWeight.Value;

            if (string.IsNullOrEmpty(barcode))
            {
                barcode = DbHelper.GenerateUniqueBarcode();
                txtProductBarcode.Text = barcode;
            }

            string err;
            bool ok = DbHelper.AddProduct(barcode, name, price, weight, out err);
            if (ok)
            {
                MessageBox.Show(
                    $"Товар «{name}» успешно добавлен в базу данных!\n\n" +
                    $"Штрихкод: {barcode}\n" +
                    $"Цена: {price:N2} руб.\n" +
                    $"Вес: {weight:N3} кг\n\n" +
                    "Запись внесена в файл Продуктовый.accdb и теперь доступна всем покупателям в каталоге онлайн-маркета.",
                    "Товар добавлен",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                RefreshAllData();
                ClearProductForm();
            }
            else
            {
                MessageBox.Show(err, "Не удалось добавить товар", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnEditProduct_Click(object sender, EventArgs e)
        {
            string barcode = txtProductBarcode.Text.Trim();
            string name = txtProductName.Text.Trim();
            decimal price = numProductPrice.Value;
            double weight = (double)numProductWeight.Value;

            if (string.IsNullOrEmpty(barcode))
            {
                MessageBox.Show("Штрихкод товара не указан! Пожалуйста, выберите товар из списка слева.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string err;
            bool ok = DbHelper.UpdateProduct(barcode, name, price, weight, out err);
            if (ok)
            {
                MessageBox.Show(
                    $"Данные товара «{name}» успешно обновлены в базе данных!\n\n" +
                    $"Штрихкод: {barcode}\n" +
                    $"Новая цена: {price:N2} руб.\n" +
                    $"Новый вес: {weight:N3} кг",
                    "Товар обновлен",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                RefreshAllData();
            }
            else
            {
                MessageBox.Show(err, "Не удалось обновить товар", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BtnDeleteProduct_Click(object sender, EventArgs e)
        {
            if (dgvProducts.CurrentRow == null || dgvProducts.CurrentRow.DataBoundItem == null)
            {
                MessageBox.Show("Пожалуйста, выберите товар из списка слева для удаления!", "Товар не выбран", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            DataRowView rowView = dgvProducts.CurrentRow.DataBoundItem as DataRowView;
            if (rowView == null) return;

            string barcode = rowView["Штрихкод"] != DBNull.Value ? rowView["Штрихкод"].ToString() : "";
            string name = rowView["Наименование"] != DBNull.Value ? rowView["Наименование"].ToString() : "";

            var confirm = MessageBox.Show(
                $"Вы действительно хотите удалить товар «{name}» (штрихкод: {barcode}) из базы данных?\n\nВнимание: если товар уже заказывался в ранее оформленных заказах, база данных отклонит удаление для сохранения целостности истории.",
                "Подтверждение удаления",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes) return;

            string err;
            bool ok = DbHelper.DeleteProduct(barcode, out err);
            if (ok)
            {
                MessageBox.Show($"Товар «{name}» успешно удален из базы данных!", "Товар удален", MessageBoxButtons.OK, MessageBoxIcon.Information);
                RefreshAllData();
                ClearProductForm();
            }
            else
            {
                MessageBox.Show(err, "Невозможно удалить товар", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
