using System;
using System.Drawing;
using System.Windows.Forms;

namespace GroceryStoreOnline
{
    public class FormAuth : Form
    {
        private TabControl tabControl;
        private TabPage tabLogin;
        private TabPage tabRegister;

        // Элементы вкладки "Вход" (роль определяется автоматически)
        private TextBox txtLogin;
        private TextBox txtPassword;
        private Button btnLogin;
        private Button btnGoToRegister;
        private Label lblHint;

        // Элементы вкладки "Регистрация" (для новых покупателей)
        private TextBox txtRegFio;
        private TextBox txtRegPhone;
        private TextBox txtRegAddress;
        private TextBox txtRegLogin;
        private TextBox txtRegPassword;
        private Button btnRegister;
        private Button btnBackToLogin;

        public FormAuth()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Онлайн-маркет «Продуктовый» — Вход в систему";
            this.Size = new Size(490, 450);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point, ((byte)(204)));
            this.BackColor = Color.FromArgb(245, 247, 250);

            // Главный заголовок
            Label lblHeader = new Label
            {
                Text = "Онлайн-маркет «Продуктовый»",
                Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, ((byte)(204))),
                ForeColor = Color.FromArgb(33, 43, 54),
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Top,
                Height = 50
            };
            this.Controls.Add(lblHeader);

            tabControl = new TabControl
            {
                Dock = DockStyle.Fill,
                Padding = new Point(15, 6)
            };

            // ==========================================
            // ВКЛАДКА 1: ВХОД В СИСТЕМУ
            // ==========================================
            tabLogin = new TabPage(" Вход в аккаунт ");
            tabLogin.BackColor = Color.White;

            Label lblLog = new Label
            {
                Text = "Логин:",
                Location = new Point(35, 20),
                AutoSize = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold)
            };
            txtLogin = new TextBox
            {
                Location = new Point(35, 45),
                Width = 400,
                Font = new Font("Segoe UI", 11F)
            };

            Label lblPwd = new Label
            {
                Text = "Пароль:",
                Location = new Point(35, 85),
                AutoSize = true,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold)
            };
            txtPassword = new TextBox
            {
                Location = new Point(35, 110),
                Width = 400,
                Font = new Font("Segoe UI", 11F),
                UseSystemPasswordChar = true
            };

            btnLogin = new Button
            {
                Text = "Войти в систему",
                Location = new Point(35, 160),
                Size = new Size(400, 42),
                BackColor = Color.FromArgb(0, 120, 215),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.Click += BtnLogin_Click;

            btnGoToRegister = new Button
            {
                Text = "Новый покупатель? Зарегистрироваться",
                Location = new Point(35, 212),
                Size = new Size(400, 36),
                BackColor = Color.FromArgb(235, 243, 252),
                ForeColor = Color.FromArgb(0, 102, 204),
                Font = new Font("Segoe UI", 9.5F, FontStyle.Regular),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnGoToRegister.FlatAppearance.BorderColor = Color.FromArgb(179, 215, 255);
            btnGoToRegister.Click += (s, e) => { tabControl.SelectedTab = tabRegister; };

            lblHint = new Label
            {
                Text = "Подсказка для проверки:\nАдминистратор: admin / admin\nПокупатели: buyer1, buyer2, buyer3, buyer4, buyer5",
                Location = new Point(35, 260),
                Size = new Size(400, 55),
                ForeColor = Color.DimGray,
                Font = new Font("Segoe UI", 8.5F)
            };

            tabLogin.Controls.Add(lblLog);
            tabLogin.Controls.Add(txtLogin);
            tabLogin.Controls.Add(lblPwd);
            tabLogin.Controls.Add(txtPassword);
            tabLogin.Controls.Add(btnLogin);
            tabLogin.Controls.Add(btnGoToRegister);
            tabLogin.Controls.Add(lblHint);

            // ==========================================
            // ВКЛАДКА 2: РЕГИСТРАЦИЯ ПОКУПАТЕЛЯ
            // ==========================================
            tabRegister = new TabPage(" Регистрация покупателя ");
            tabRegister.BackColor = Color.White;

            Label lblRegNotice = new Label
            {
                Text = "Регистрация нового покупателя (для администратора вход по логину admin)",
                Location = new Point(25, 10),
                Size = new Size(420, 20),
                Font = new Font("Segoe UI", 8.5F, FontStyle.Italic),
                ForeColor = Color.DarkSlateGray
            };

            Label lblRFio = new Label { Text = "ФИО покупателя:", Location = new Point(25, 35), AutoSize = true };
            txtRegFio = new TextBox { Location = new Point(25, 58), Width = 420 };

            Label lblRPhone = new Label { Text = "Телефон:", Location = new Point(25, 92), AutoSize = true };
            txtRegPhone = new TextBox { Location = new Point(25, 115), Width = 200, Text = "+7 (999) 000-00-00" };

            Label lblRLogin = new Label { Text = "Желаемый логин:", Location = new Point(235, 92), AutoSize = true };
            txtRegLogin = new TextBox { Location = new Point(235, 115), Width = 210 };

            Label lblRAddress = new Label { Text = "Адрес доставки (куда привозить заказы):", Location = new Point(25, 150), AutoSize = true };
            txtRegAddress = new TextBox { Location = new Point(25, 173), Width = 420, Text = "г. Москва, ул. " };

            Label lblRPwd = new Label { Text = "Придумайте пароль:", Location = new Point(25, 208), AutoSize = true };
            txtRegPassword = new TextBox { Location = new Point(25, 231), Width = 420, UseSystemPasswordChar = true };

            btnRegister = new Button
            {
                Text = "Зарегистрироваться и войти",
                Location = new Point(25, 275),
                Size = new Size(260, 42),
                BackColor = Color.FromArgb(40, 167, 69),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 10.5F, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnRegister.FlatAppearance.BorderSize = 0;
            btnRegister.Click += BtnRegister_Click;

            btnBackToLogin = new Button
            {
                Text = "Назад ко входу",
                Location = new Point(295, 275),
                Size = new Size(150, 42),
                BackColor = Color.LightGray,
                ForeColor = Color.Black,
                Font = new Font("Segoe UI", 9.5F),
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnBackToLogin.FlatAppearance.BorderSize = 0;
            btnBackToLogin.Click += (s, e) => { tabControl.SelectedTab = tabLogin; };

            tabRegister.Controls.Add(lblRegNotice);
            tabRegister.Controls.Add(lblRFio);
            tabRegister.Controls.Add(txtRegFio);
            tabRegister.Controls.Add(lblRPhone);
            tabRegister.Controls.Add(txtRegPhone);
            tabRegister.Controls.Add(lblRLogin);
            tabRegister.Controls.Add(txtRegLogin);
            tabRegister.Controls.Add(lblRAddress);
            tabRegister.Controls.Add(txtRegAddress);
            tabRegister.Controls.Add(lblRPwd);
            tabRegister.Controls.Add(txtRegPassword);
            tabRegister.Controls.Add(btnRegister);
            tabRegister.Controls.Add(btnBackToLogin);

            tabControl.TabPages.Add(tabLogin);
            tabControl.TabPages.Add(tabRegister);
            this.Controls.Add(tabControl);

            this.AcceptButton = btnLogin;
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Пожалуйста, заполните логин и пароль!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Роль определяется автоматически по учетной записи в базе данных
                User user = DbHelper.Authenticate(login, password);
                if (user == null)
                {
                    MessageBox.Show(
                        "Неверный логин или пароль!\n\n" +
                        "Пожалуйста, проверьте правильность введенных данных или зарегистрируйтесь.",
                        "Ошибка входа",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    return;
                }

                // Успешный вход: скрываем окно авторизации
                this.Hide();

                // Автоматически направляем в нужный интерфейс в зависимости от роли в БД
                if (string.Equals(user.Role, "Admin", StringComparison.OrdinalIgnoreCase))
                {
                    using (FormAdmin adminForm = new FormAdmin(user))
                    {
                        adminForm.ShowDialog();
                    }
                }
                else
                {
                    using (FormBuyer buyerForm = new FormBuyer(user))
                    {
                        buyerForm.ShowDialog();
                    }
                }

                // После закрытия формы снова показываем форму входа
                this.Show();
                txtPassword.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при подключении к базе данных:\n" + ex.Message, "Ошибка БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            string fio = txtRegFio.Text.Trim();
            string phone = txtRegPhone.Text.Trim();
            string login = txtRegLogin.Text.Trim();
            string address = txtRegAddress.Text.Trim();
            string password = txtRegPassword.Text.Trim();

            if (string.IsNullOrEmpty(fio) || string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Поля «ФИО», «Логин» и «Пароль» обязательны для заполнения!", "Заполните поля", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string error;
                User newUser = DbHelper.RegisterBuyer(login, password, fio, phone, address, out error);
                if (newUser == null)
                {
                    MessageBox.Show(error, "Ошибка регистрации", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                MessageBox.Show(
                    $"Поздравляем, {newUser.FullName}!\nВы успешно зарегистрированы в онлайн-магазине!\n\n" +
                    "Вам автоматически выпущена виртуальная карта лояльности с 100 приветственными бонусами.\n" +
                    "При последующих входах просто вводите ваш логин и пароль.",
                    "Успешная регистрация",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                // Открываем личный кабинет покупателя
                this.Hide();
                using (FormBuyer buyerForm = new FormBuyer(newUser))
                {
                    buyerForm.ShowDialog();
                }
                this.Show();

                // Очистка полей регистрации
                txtRegFio.Clear();
                txtRegLogin.Clear();
                txtRegPassword.Clear();
                tabControl.SelectedTab = tabLogin;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при регистрации:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
